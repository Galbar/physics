g++ -Wall  -I. inertialmomentum.cc -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -o inertialmomentum
