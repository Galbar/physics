g++ -Wall  -I. inertialmomentum.1.cc -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -o inertialmomentum.1
g++ -Wall  -I. inertialmomentum.2.cc -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -o inertialmomentum.2
g++ -Wall  -I. inertialmomentum.cc -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -o inertialmomentum
