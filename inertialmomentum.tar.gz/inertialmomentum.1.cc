#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Graphics/Shape.hpp>
#include <SFML/Graphics/RectangleShape.hpp>

#include <iostream>
#include <complex>
#include <cmath>
#include <fstream>
#include <cstdlib>
#include <queue>
#include <sstream>

//#include "Box2D/Box2D.h"


using namespace std;

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Basic functions

double sq(double x)
{
  return x*x;
}

double error=1e-5;

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Definition of points

typedef complex<double> point;

double prod_esc(point p1,point p2)
{
  return real(conj(p1)*p2);
}

double prod_vec(point p1,point p2)
{
  return imag(conj(p1)*p2);
}

point unitary(point p)
{
  return (1.0/abs(p))*p;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Definition and initialization of Bodies.

struct Fixture {
  double r; // radious
  point p; // position
  double d; // density
  double f; // friction
  double res; // restitution
  sf::Color color; // surrounding color
  Fixture() {}
  Fixture(double r,point p,double d,double f,double res,sf::Color color):
    r(r),p(p),d(d),f(f),res(res),color(color) {}
};

struct Body {
  point c; // mass center
  double rot; // rotation w.r.t. center
  point v; // linear velocity
  double w; // angular velocity
  double I; // inertial momentum
  double m; // mass
  vector<Fixture> vf;
  sf::Color color; // Interior color of each fixture.
  Body() {}
  Body(point v,double w,sf::Color color):v(v),w(w),color(color) {}
};

void compute_mass(Body &b)
{
  b.m=0;
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++) {
    Fixture &f=vf[i];
    b.m+=f.d*M_PI*sq(f.r);
  }
}

void compute_mass_center(Body &b)
{
  b.c=point(0,0);
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++) {
    Fixture &f=vf[i];
    b.c+=f.d*M_PI*sq(f.r)*f.p;
  }
  b.c=(1.0/b.m)*b.c;
}

// Approximate computation of inertial momentum of
// a Fixture with respect to a position,
// based on approximating integration with
// small squares (0.1*r)x(0.1*r) (with area 0.01*r*r).
double compute_inertial_momentum(Fixture f,point c)
{
  double I=0;
  for (int x=-10;x<=10;x++) {
    for (int y=-10;y<=10;y++) {
      point desp(f.r*double(x)/10,f.r*double(y)/10);
      if (abs(desp)<f.r)
	I+=norm(f.p+desp-c)*f.d*sq(0.1*f.r);
    }
  }
  return I;
}

// Approximate computation of inertial momentum of a Body
// with respect to its mass center.
void compute_inertial_momentum(Body &b)
{
  b.I=0;
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++)
    b.I+=compute_inertial_momentum(vf[i],b.c);
}

void make_positions_relative_to_mass_center(Body &b)
{
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++)
    vf[i].p-=b.c;
}

// This function assumes that the Fixtures of b have the positions
// initialized as absolute coordinates, and all the rest of atributes initialized as well.
// The function computes the total mass, mass center, inertial momentum
// of the body, and make the positions of the fixtures relative to
// the mass center. It initializes the rotation to 0, and assumes
// that the linear and angular velocities are already initialized,
void precompute_body_values(Body &b)
{
  compute_mass(b);
  compute_mass_center(b);
  compute_inertial_momentum(b);
  make_positions_relative_to_mass_center(b);
  b.rot=0;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Detection of collisions

struct Collision {
  point p;
  point n; // normal outgoing from b1
  Body *b1;
  Body *b2;
  double res; // restitution
  double f; // friction
};

void compute_collision(Body &b1,int i1,Body &b2,int i2,
		       bool &thereiscollision,Collision &col)
{
  Fixture &f1=b1.vf[i1];
  Fixture &f2=b2.vf[i2];
  point c1=b1.c+polar(1.0,b1.rot)*f1.p;
  point c2=b2.c+polar(1.0,b2.rot)*f2.p;
  thereiscollision=abs(c2-c1)>error and abs(c2-c1)<f1.r+f2.r;
  if (not thereiscollision) return;
  col.n=unitary(c2-c1);
  point p1=c1+col.n*f1.r;
  point p2=c2-col.n*f2.r;
  col.p=0.5*(p1+p2);
  col.b1=&b1;
  col.b2=&b2;
  col.res=min(f1.res,f2.res);
  col.f=min(f1.f,f2.f);
}

void compute_collisions(Body &b1,Body &b2,vector<Collision> &vc)
{
  for (int i1=0;i1<int(b1.vf.size());i1++) {
    for (int i2=0;i2<int(b2.vf.size());i2++) {
      bool thereiscollision;
      Collision col;
      compute_collision(b1,i1,b2,i2,thereiscollision,col);
      if (thereiscollision)
	vc.push_back(col);
    }
  }
}

vector<Collision> compute_collisions(vector<Body> &vb)
{
  vector<Collision> vc;
  for (int i1=0;i1<int(vb.size());i1++)
    for (int i2=i1+1;i2<int(vb.size());i2++)
      compute_collisions(vb[i1],vb[i2],vc);
  return vc;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Resolution of collisions

struct Resolution {
  Body *b;
  point p;
  point impulse;
  Resolution() {}
  Resolution(Body *b,point p,point impulse):b(b),p(p),impulse(impulse) {}
};

void apply_impulse(Body &b,point p,point impulse)
{
  b.v+=(1.0/b.m)*impulse;
  b.w+=(1.0/b.I)*prod_vec(p-b.c,impulse);
}

point get_velocity(Body &b,point p)
{
  return b.v+b.w*(point(0,1)*(p-b.c));
}


/*
struct Collision {
  point p;
  point n; // normal outgoing from b1
  Body *b1;
  Body *b2;
  double res; // restitution
  double f; // friction
};
 */
void compute_resolution(Collision col,vector<Resolution> &vr)
{
  point p=col.p;
  point n=col.n;
  Body &b1=*col.b1;
  Body &b2=*col.b2;
  double res=col.res;
  point v1=get_velocity(b1,p);
  point v2=get_velocity(b2,p);
  point v21=v2-v1;
  if (prod_esc(v21,n)>=0) return;
  double factor=-(1+res)*prod_esc(v21,n)/
      (1.0/b1.m+1.0/b2.m+sq(prod_vec(p-b1.c,n))/b1.I+sq(prod_vec(p-b2.c,n))/b2.I);
  vr.push_back(Resolution(&b1,p,(-factor)*n));
  vr.push_back(Resolution(&b2,p,factor*n));
}

void resolve_collisions(vector<Collision> vc)
{
  vector<Resolution> vr;
  for (int i=0;i<int(vc.size());i++)
    compute_resolution(vc[i],vr);
  for (int i=0;i<int(vr.size());i++) {
    Resolution &r=vr[i];
    apply_impulse(*r.b,r.p,r.impulse);
  }
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Global movement of the world

void move_bodies(vector<Body> &vb,double delta)
{
  for (int i=0;i<int(vb.size());i++) {
    Body &b=vb[i];
    b.c+=delta*b.v;
    b.rot+=delta*b.w;
  }
  resolve_collisions(compute_collisions(vb));
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Drawing

sf::Font font;

void charge_font()
{
  if (!font.loadFromFile("font.otf")) {
    cout<<"The font could not be charged"<<endl;
    exit(0);
  }
}

void draw_text(sf::RenderWindow &window,int x,int y,string s)
{
  sf::Text text;
  text.setString(s);
  text.setFont(font);
  text.setColor(sf::Color::White);
  text.setOrigin(sf::Vector2f(0,text.getLocalBounds().height/2.0));
  text.setScale(sf::Vector2f(0.5,0.5));
  //text.setScale(sf::Vector2f(float(ladoboton)/text.getLocalBounds().height,float(ladoboton)/text.getLocalBounds().height));
  text.setPosition(sf::Vector2f(x,y));
  window.draw(text);
}

void draw_circle(sf::RenderWindow &window,float x,float y,float r,sf::Color c)
{
  sf::CircleShape circle;
  circle.setRadius(r);
  circle.setFillColor(c);
  circle.setOrigin(r,r);
  circle.setPosition(x,y);
  window.draw(circle);
}

int visible=1;

void draw_body(sf::RenderWindow &window,Body &b)
{
  if (visible) {
    for (int i=0;i<int(b.vf.size());i++) {
      Fixture &f=b.vf[i];
      point p=b.c+polar(1.0,b.rot)*f.p;
      draw_circle(window,real(p),imag(p),f.r,b.color);
    }
  }
  draw_circle(window,real(b.c),imag(b.c),1,sf::Color::Red);
}

void draw_world(sf::RenderWindow &window,vector<Body> &vb)
{
  window.clear(sf::Color::Black);
  for (int i=0;i<int(vb.size());i++)
    draw_body(window,vb[i]);
  draw_text(window,10,10,"DIRECTION: UP,DOWN,RIGHT,LEFT");
  draw_text(window,10,40,"MODE VEL/ACC: F1");
  draw_text(window,10,70,"BODY SELECT: F2");
  draw_text(window,10,100,"EXIT: ESC");  
  window.display();
} 


//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// main

const int SCRWIDTH  = 600;
const int SCRHEIGHT = 600;
const double VELOCITY=40;
const double ACCELERATION=120;

void read_keys(int mode,point &a,point &v,sf::Keyboard::Key up,sf::Keyboard::Key down,sf::Keyboard::Key right,sf::Keyboard::Key left)
{
  if (mode==0) {
    v=point(0,0);
    if (sf::Keyboard::isKeyPressed(up))
      v+=point(0,-VELOCITY);
    if (sf::Keyboard::isKeyPressed(down))
      v+=point(0,VELOCITY);
    if (sf::Keyboard::isKeyPressed(right))
      v+=point(VELOCITY,0);
    if (sf::Keyboard::isKeyPressed(left))
      v+=point(-VELOCITY,0);
  } else {
    if (sf::Keyboard::isKeyPressed(up))
      a+=point(0,-ACCELERATION);
    if (sf::Keyboard::isKeyPressed(down))
      a+=point(0,ACCELERATION);
    if (sf::Keyboard::isKeyPressed(right))
      a+=point(ACCELERATION,0);
    if (sf::Keyboard::isKeyPressed(left))
      a+=point(-ACCELERATION,0);
  }
}

void run(sf::RenderWindow &window,vector<Body> &vb)
{
  for (int i=0;i<int(vb.size());i++)
    precompute_body_values(vb[i]);
  sf::Clock clock;
  int ibkeys=0;
  int mode=1;
  for (;;) {
    sf::Event event;
    while (window.pollEvent(event)) {
      switch (event.type) {
      case sf::Event::Closed:
	window.close();
	exit(0);
	break;
      case sf::Event::KeyPressed:
	if (event.key.code == sf::Keyboard::Escape) {
	  //window.close();
	  return;
	} else if (event.key.code == sf::Keyboard::F1) {
	  mode=(mode+1)%2;
	} else if (event.key.code == sf::Keyboard::F2) {
	  ibkeys=(ibkeys+1)%int(vb.size());
	} else if (event.key.code == sf::Keyboard::F3) {
	  visible=(visible+1)%2;
	}
      case sf::Event::MouseButtonPressed:
      default:
	break;
      }
    }
    double delta = clock.restart().asSeconds();
    point v(0,0);
    point a(0,0);
    read_keys(mode,a,v,sf::Keyboard::Up,sf::Keyboard::Down,sf::Keyboard::Right,sf::Keyboard::Left);
    if (mode==0) vb[ibkeys].v=v;
    else vb[ibkeys].v+=delta*a;
    move_bodies(vb,delta);
    draw_world(window,vb);
  }
}

int main()
{
  point p=polar(1.0,1.0);
  cout<<real(p)<<","<<imag(p)<<endl;
  sf::RenderWindow window;
  window.create(sf::VideoMode(SCRWIDTH,SCRHEIGHT),"Inertial momentum");
  charge_font();
  vector<Body> vb;
  //Fixture(double r,point p,double d,double f,double res,sf::Color color)
  //Body(point v,double w,sf::Color color)
  // First body:
  vb.push_back(Body(point(0,0),0,sf::Color::White));
  vb.back().vf.push_back(Fixture(10,point(100,100),1,1,0.5,sf::Color::White));
  vb.back().vf.push_back(Fixture(15,point(200,100),1,1,0.5,sf::Color::White));
  // Second body:
  vb.push_back(Body(point(0,0),0,sf::Color::Blue));
  vb.back().vf.push_back(Fixture(10,point(300,200),1,1,0.5,sf::Color::Blue));
  vb.back().vf.push_back(Fixture(20,point(350,250),1,1,0.5,sf::Color::Blue));
  vb.back().vf.push_back(Fixture(5,point(280,250),1,1,0.5,sf::Color::Blue));
  run(window,vb);
}
