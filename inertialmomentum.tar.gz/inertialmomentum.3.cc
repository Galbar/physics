#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Graphics/Shape.hpp>
#include <SFML/Graphics/RectangleShape.hpp>

#include <iostream>
#include <complex>
#include <cmath>
#include <fstream>
#include <cstdlib>
#include <queue>
#include <sstream>
#include <algorithm>

//#include "Box2D/Box2D.h"


using namespace std;

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Basic functions

double error=1e-5;

void die(string s)
{
  cout<<s<<endl;
  exit(0);
}

double sq(double x)
{
  return x*x;
}

int sign(double x)
{
  if (x>0) return 1;
  if (x<0) return -1;
  return 0;
}

int my_stoi(string s)
{
  istringstream ci(s);
  string aux;
  ci>>aux;
  s=aux;
  int r=0;
  for (int i=0;i<int(s.size());i++) {
    if (not (s[i]>='0' and s[i]<='9'))
      die("Error: '"+s+"' is not int.");
    r=r*10+s[i]-'0';
  }
  return r;
}

string my_itos(int x)
{
  string s(1,char(x%10+'0'));
  while (x>=10) {
    x/=10;
    s=string(1,char(x%10+'0'))+s;
  }
  return s;
}

double stodouble(string s)
{
  istringstream mycin(s);
  double x;
  mycin>>x;
  return x;
}

string read_file(string filename)
{
  string contents;
  ifstream fcontents(filename.c_str());
  if (not fcontents.is_open())
    die("Error: could not open '"+filename+"'.");
  string s;
  getline(fcontents,contents);
  while (getline(fcontents,s))
    contents+='\n'+s;
  fcontents.close();
  return contents;
}


//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Definition of points

typedef complex<double> point;

void print(point p)
{
  cout<<"("<<real(p)<<","<<imag(p)<<")";
}

void print(vector<point> v)
{
  for (int i=0;i<int(v.size());i++)
    print(v[i]);
}

double prod_esc(point p1,point p2)
{
  return real(conj(p1)*p2);
}

double prod_vec(point p1,point p2)
{
  return imag(conj(p1)*p2);
}

point unitary(point p)
{
  return (1.0/abs(p))*p;
}

double circle_area(double r)
{
  return M_PI*sq(r);
}

// Approximate computation of inertial momentum of a circle with center c,
// radious r, and density d, with respect to a reference position ref,
// based on approximating integration with
// small squares (0.1*r)x(0.1*r) (with area 0.01*r*r).
double circle_inertia(point c,double r,double d,point ref)
{
  double I=0;
  for (int x=-10;x<=10;x++) {
    for (int y=-10;y<=10;y++) {
      point desp(r*double(x)/10,r*double(y)/10);
      if (abs(desp)<r)
	I+=norm(c+desp-ref)*d*sq(0.1*r);
    }
  }
  return I;
}

double convex_oriented_area(vector<point> vp)
{
  double a=0;
  for (int i=1;i<int(vp.size())-1;i++)
    a+=prod_vec(vp[i]-vp[0],vp[i+1]-vp[0])/2.0;
  return a;
}

double convex_area(vector<point> vp)
{
  return abs(convex_oriented_area(vp));
}

point triangle_center(point p1,point p2,point p3)
{
  return 1/3.0*(p1+p2+p3);
}

double triangle_area(point p1,point p2,point p3)
{
  return abs(prod_vec(p2-p1,p3-p1)/2.0);
}

// Computes the inertial momentum of a triangle with respect
// to a position c, with the incorrect assumption that
// all its mass was concentrated on its center of masses,
// although it is uniformly distributed with density d,
// in order to make just an approximation.
double basic_triangle_inertia(point p1,point p2,point p3,double d,point c)
{
  return norm(triangle_center(p1,p2,p3)-c)*d*triangle_area(p1,p2,p3);
}

// Approximate computation of inertial momentum of
// a triangle with density d, and with respect to a position c,
// based on approximating integration. Basically, it divides
// the triangle in small triangles for which the
// previous basic_triangle_inertia function is computed.
double triangle_inertia(point p1,point p2,point p3,double d,point c)
{
  double I=0;
  for (int i=0;i<10;i++) {
    double x=i/10.0;
    double nextx=(i+1)/10.0;
    point pa=(1.0-x)*p1+x*p2;
    point pb=(1.0-nextx)*p1+nextx*p2;
    for (int j=0;j<10;j++) {
      double y=j/10.0;
      double nexty=(j+1)/10.0;
      point pc=pa*(1.0-y)+y*p3;
      point pd=pb*(1.0-y)+y*p3;
      point pe=pa*(1.0-nexty)+nexty*p3;
      point pf=pb*(1.0-nexty)+nexty*p3;
      I+=basic_triangle_inertia(pc,pd,pe,d,c)+basic_triangle_inertia(pd,pf,pe,d,c);
    }
  }
  return I;
}

// Approximate computation of inertial momentum of
// a convex based on approximating integration.
double convex_inertia(vector<point> &vp,double d,point c)
{
  double I=0;
  for (int i=1;i<int(vp.size())-1;i++)
    I+=triangle_inertia(vp[0],vp[i],vp[i+1],d,c);
  return I;
}
		      

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Definition and initialization of Bodies.

// Each fixture is either a circle or a convex polygon.
const int CIRCLE=1;
const int CONVEX=2;
struct Fixture {
  int kind; // CIRCLE or CONVEX.
  double r; // radious (only for circles)
  point p; // position (only for circles)
  vector<point> vp; // positions (only for convex polygons)
  double d; // density
  double f; // friction
  double res; // restitution
  bool owncolor; // If false, the body color is taken
  sf::Color color; // surrounding color
  Fixture() {kind=CIRCLE;r=1;p=point(0,0);d=1;f=0;res=0.5;owncolor=false;}
  Fixture(double r,point p,double d,double f,double res,sf::Color color):
    r(r),p(p),d(d),f(f),res(res),color(color) {
    kind=CIRCLE;
  }
  // vp must represent a convex polygon as a list of clock-wise or counter-clock-wise points.
  Fixture(vector<point> vpin,double d,double f,double res,sf::Color color):d(d),f(f),res(res),color(color) {
    kind=CONVEX;
    vp=vpin;
    if (convex_oriented_area(vp)<0)
      reverse(vp.begin(),vp.end());
  }
};

struct Body {
  point c; // mass center
  double rot; // rotation w.r.t. center
  point v; // linear velocity
  double w; // angular velocity
  double I; // inertial momentum
  double m; // mass
  vector<Fixture> vf;
  sf::Color color; // Interior color of each fixture.
  Body() {v=point(0,0);w=0;color=sf::Color::White;}
  Body(point v,double w,sf::Color color):v(v),w(w),color(color) {}
};

struct World {
  string description;
  vector<Body> vb;
};

point get_absolute_point(Body &b,point p)
{
  return b.c+polar(1.0,b.rot)*p;
}

vector<point> get_absolute_points(Body &b,Fixture &f)
{
  vector<point> vp;
  for (int j=0;j<int(f.vp.size());j++)
    vp.push_back(get_absolute_point(b,f.vp[j]));
  return vp;
}

double compute_mass(Fixture &f)
{
  return f.d*(f.kind==CIRCLE?circle_area(f.r):convex_area(f.vp));
}

void compute_mass(Body &b)
{
  b.m=0;
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++)
    b.m+=compute_mass(vf[i]);
}

point compute_mass_sum_vector(Fixture &f)
{
  if (f.kind==CIRCLE)
    return compute_mass(f)*f.p;
  vector<point> &vp=f.vp;
  point c(0,0);
  for (int i=1;i<int(vp.size())-1;i++)
    c+=f.d*triangle_area(vp[0],vp[i],vp[i+1])*triangle_center(vp[0],vp[i],vp[i+1]);
  return c;
}

void compute_mass_center(Body &b)
{  
  b.c=point(0,0);
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++)
    b.c+=compute_mass_sum_vector(vf[i]);
  b.c=(1.0/b.m)*b.c;
}

// Approximate computation of inertial momentum of
// a Fixture with respect to a position c.
double compute_inertia(Fixture f,point c)
{
  return f.kind==CIRCLE?circle_inertia(f.p,f.r,f.d,c):convex_inertia(f.vp,f.d,c);
}

// Approximate computation of inertial momentum of a Body
// with respect to its mass center.
void compute_inertia(Body &b)
{
  b.I=0;
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++)
    b.I+=compute_inertia(vf[i],b.c);
}

void make_positions_relative_to_mass_center(Body &b)
{
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++) {
    Fixture &f=vf[i];
    if (f.kind==CIRCLE) f.p-=b.c;
    else {
      vector<point> &vp=f.vp;
      for (int j=0;j<int(vp.size());j++)
	vp[j]-=b.c;
    }
  }
}

void orient_polygons(Body &b)
{
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++) {
    Fixture &f=vf[i];
    if (f.kind==CONVEX) {
      vector<point> &vp=f.vp;
      if (convex_oriented_area(vp)<0)
	reverse(vp.begin(),vp.end());
    }
  }
}

// This function assumes that the Fixtures of b have the positions
// initialized as absolute coordinates, and all the rest of atributes initialized as well.
// The function computes the total mass, mass center, inertial momentum
// of the body, and make the positions of the fixtures relative to
// the mass center. It initializes the rotation to 0, and assumes
// that the linear and angular velocities are already initialized,
void precompute_body_values(Body &b)
{
  compute_mass(b);
  compute_mass_center(b);
  compute_inertia(b);
  make_positions_relative_to_mass_center(b);
  orient_polygons(b);
  b.rot=0;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Detection of contacts

struct ContactSide {
  point p,p1,p2; // p used for circle-convex, p1,p2 used for convex-convex.
  point n;
  double projection; // Negated of penetration
};

bool operator<(ContactSide cs1,ContactSide cs2)
{
  return cs1.projection<cs2.projection;
}

ContactSide compute_min_projection_contact_side(point p1,point p2,vector<point> &v)
{
  ContactSide cs;
  cs.p1=p1;
  cs.p2=p2;
  cs.n=unitary((p2-p1)*point(0,-1));
  cs.projection=prod_esc(cs.n,v[0]-cs.p1);
  for (int i=1;i<int(v.size());i++)
    cs.projection=min(cs.projection,prod_esc(cs.n,v[i]-cs.p1));
  return cs;
}

ContactSide compute_max_projection_contact_side(vector<point> &v1,vector<point> &v2)
{
  ContactSide cs=compute_min_projection_contact_side(v1[0],v1[1],v2);
  for (int i=1;i<int(v1.size());i++) {
    int nexti=(i+1)%int(v1.size());
    cs=max(cs,compute_min_projection_contact_side(v1[i],v1[nexti],v2));
  }
  return cs;
}

struct Contact {
  point p;
  point n; // normal outgoing from b1
  Body *b1;
  Body *b2;
  double projection; // negation of penetration.
  double res; // restitution
  double f; // friction
};

bool operator<(Contact c1,Contact c2)
{
  return c1.projection<c2.projection;
}

void compute_contacts_convex_convex(Body &b1,Fixture &f1,Body &b2,Fixture &f2,vector<point> vp2,
				     vector<Contact> &vc,ContactSide &cs)
{
  for (int i=0;i<int(vp2.size());i++) {
    point p2=vp2[i];
    if (prod_esc(cs.n,p2-cs.p1)<error) {
      Contact con;
      con.n=cs.n;
      con.b1=&b1;
      con.b2=&b2;
      con.projection=prod_esc(cs.n,p2-cs.p1);
      con.res=min(f1.res,f2.res);
      con.f=min(f1.f,f2.f);
      point projection=p2+prod_esc(cs.n,cs.p1-p2)*cs.n;
      double pv=prod_vec(cs.n,projection-cs.p1);
      if (pv<-error)
	con.p=0.5*(p2+cs.p1-projection+cs.p1);
      else if (pv>prod_vec(cs.n,cs.p2-cs.p1)+error)
	con.p=0.5*(p2+cs.p2-projection+cs.p2);
      else
	con.p=0.5*(p2+projection);
      vc.push_back(con);
    }
  }
}

void compute_contacts_convex_convex(Body &b1,Fixture &f1,Body &b2,Fixture &f2,
				    vector<Contact> &vc)
{
  vector<point> vp1=get_absolute_points(b1,f1);
  vector<point> vp2=get_absolute_points(b2,f2);
  ContactSide cs1=compute_max_projection_contact_side(vp1,vp2);
  ContactSide cs2=compute_max_projection_contact_side(vp2,vp1);
  if (cs1<cs2) {
    if (cs2.projection>error) return;
    compute_contacts_convex_convex(b2,f2,b1,f1,vp1,vc,cs2);
  } else {
    if (cs1.projection>error) return;
    compute_contacts_convex_convex(b1,f1,b2,f2,vp2,vc,cs1);
  }
}

void compute_contacts_circle_circle(Body &b1,Fixture &f1,Body &b2,Fixture &f2,
				    vector<Contact> &vc)
{
  point c1=get_absolute_point(b1,f1.p);
  point c2=get_absolute_point(b2,f2.p);
  Contact con;
  con.projection=abs(c2-c1)-(f1.r+f2.r);
  if (con.projection>error) return;
  if (abs(c2-c1)<error) con.n=point(1,0);
  else con.n=unitary(c2-c1);
  point p1=c1+con.n*f1.r;
  point p2=c2-con.n*f2.r;
  con.p=0.5*(p1+p2);
  con.b1=&b1;
  con.b2=&b2;
  con.res=min(f1.res,f2.res);
  con.f=min(f1.f,f2.f);
  vc.push_back(con);
}

struct ContactPoint {
  point p;
  point n;
};

// pprev,p,pnext are consecutive points of a convex.
// The returned contact point is centered at p.
// The normal points from p to c if the angle pprev,p,pnext contains c.
// Otherwise, the normal points from c to p.
ContactPoint compute_contact_point(point c,point pprev,point p,point pnext)
{
  ContactPoint cp;
  cp.p=p;
  if (abs(c-p)<error) cp.n=unitary(unitary(pprev-p)+unitary(pnext-p));
  else if (prod_vec(pnext-p,c-p)>0 and prod_vec(c-p,pprev-p)>0) cp.n=unitary(c-p);
  else cp.n=unitary(p-c);
  return cp;
}

// Returns the closest contact point to c among cp1 and cp2.
ContactPoint compute_contact_point(point c,ContactPoint cp1,ContactPoint cp2)
{
  if (abs(c-cp1.p)<abs(c-cp2.p)) return cp1;
  return cp2;
}

// p0,p1,p2,p3 are consecutive points of a convex (perhaps p0==p3).
// If the closest point to c from the segment (p1,p2) either p1 or p2,
// then this function returns the closest contact point to c among the
// results of the calls compute_contact_point(c,p0,p1,p2)
// and compute_contact_point(p1,p2,p3).
// Otherwise, the closest p to c from the segment (p1,p2) is the
// center of the returned contact point, and the normal points
// to inside the convex.
ContactPoint compute_contact_point(point c,point p0,point p1,point p2,point p3)
{
  point dir=unitary(p2-p1);
  //cout<<"caso ";print(p1);print(p2);print(dir);cout<<endl;
  if (sign(prod_esc(dir,p1-c))==sign(prod_esc(dir,p2-c)))
    return compute_contact_point(c,
				 compute_contact_point(c,p0,p1,p2),
				 compute_contact_point(c,p1,p2,p3));
  //cout<<"supera"<<endl;
  ContactPoint cp;
  cp.n=dir*point(0,1);
  cp.p=c+prod_esc(cp.n,p1-c)*cp.n;
  return cp;
}

// Computes the closest contact point to c among the points of the
// convex vp.
ContactPoint compute_contact_point(point c,vector<point> vp)
{
  //cout<<"compute ";print(c);cout<<" ";print(vp);cout<<endl;
  ContactPoint cp=compute_contact_point(c,vp[0],vp[1],vp[2]);
  for (int i=0;i<int(vp.size());i++) {
    int i0=i;
    int i1=(i+1)%int(vp.size());
    int i2=(i+2)%int(vp.size());
    int i3=(i+3)%int(vp.size());
    cp=compute_contact_point(c,cp,compute_contact_point(c,vp[i0],vp[i1],vp[i2],vp[i3]));
  }
  return cp;
}

void compute_contacts_circle_convex(Body &b1,Fixture &f1,Body &b2,Fixture &f2,
				    vector<Contact> &vc)
{
  //cout<<"circle convex"<<endl;
  point c1=get_absolute_point(b1,f1.p);
  ContactPoint cp=compute_contact_point(c1,get_absolute_points(b2,f2));
  //cout<<"contact point: ";print(cp.p);print(cp.n);cout<<endl;
  Contact con;
  point perimeter=c1+cp.n*f1.r;
  con.projection=prod_esc(cp.n,cp.p-perimeter);
  //exit(0);
  if (con.projection>error) return;
  con.p=0.5*(cp.p+perimeter);
  con.n=cp.n;
  con.b1=&b1;
  con.b2=&b2;
  con.res=min(f1.res,f2.res);
  con.f=min(f1.f,f2.f);
  vc.push_back(con);
  //exit(0);
}

void compute_contacts(Body &b1,Body &b2,vector<Contact> &vc)
{
  for (int i1=0;i1<int(b1.vf.size());i1++) {
    Fixture &f1=b1.vf[i1];
    for (int i2=0;i2<int(b2.vf.size());i2++) {
      Fixture &f2=b2.vf[i2];
      if (f1.kind==CIRCLE and f2.kind==CIRCLE)
	compute_contacts_circle_circle(b1,f1,b2,f2,vc);
      else if (f1.kind==CIRCLE and f2.kind==CONVEX)
	compute_contacts_circle_convex(b1,f1,b2,f2,vc);
      else if (f1.kind==CONVEX and f2.kind==CIRCLE)
	compute_contacts_circle_convex(b2,f2,b1,f1,vc);
      else
	compute_contacts_convex_convex(b1,f1,b2,f2,vc);
    }
  }
}

vector<Contact> compute_contacts(vector<Body> &vb)
{
  vector<Contact> vc;
  for (int i1=0;i1<int(vb.size());i1++)
    for (int i2=i1+1;i2<int(vb.size());i2++)
      compute_contacts(vb[i1],vb[i2],vc);
  return vc;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Resolution of contacts

struct Resolution {
  Body *b;
  point p;
  point impulse;
  Resolution() {}
  Resolution(Body *b,point p,point impulse):b(b),p(p),impulse(impulse) {}
};

void apply_impulse(Body &b,point p,point impulse)
{
  b.v+=(1.0/b.m)*impulse;
  b.w+=(1.0/b.I)*prod_vec(p-b.c,impulse);
}

point get_velocity(Body &b,point p)
{
  return b.v+b.w*(point(0,1)*(p-b.c));
}


/*
struct Contact {
  point p;
  point n; // normal outgoing from b1
  Body *b1;
  Body *b2;
  double res; // restitution
  double f; // friction
};
 */
vector<Resolution> compute_resolution(Contact col)
{
  vector<Resolution> vr;
  point p=col.p;
  point n=col.n;
  Body &b1=*col.b1;
  Body &b2=*col.b2;
  double res=col.res;
  point v1=get_velocity(b1,p);
  point v2=get_velocity(b2,p);
  point v21=v2-v1;
  if (prod_esc(v21,n)>=0) return vr;
  double factor=-(1+res)*prod_esc(v21,n)/
      (1.0/b1.m+1.0/b2.m+sq(prod_vec(p-b1.c,n))/b1.I+sq(prod_vec(p-b2.c,n))/b2.I);
  vr.push_back(Resolution(&b1,p,(-factor)*n));
  vr.push_back(Resolution(&b2,p,factor*n));
  return vr;
}

void resolve_contacts(vector<Contact> vc)
{
  for (int paso=0;paso<20;paso++) {
    bool found=false;
    for (int i=0;i<int(vc.size()) and not found;i++) {
      vector<Resolution> vr=compute_resolution(vc[i]);
      if (int(vr.size())>0) {
	found=true;
	for (int i=0;i<int(vr.size());i++) {
	  Resolution &r=vr[i];
	  apply_impulse(*r.b,r.p,r.impulse);
	}
      }
    }
    if (not found) return;
  }
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Global movement of the world

void move_bodies(vector<Body> &vb,double delta)
{
  for (int i=0;i<int(vb.size());i++) {
    Body &b=vb[i];
    b.c+=delta*b.v;
    b.rot+=delta*b.w;
  }
  resolve_contacts(compute_contacts(vb));
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Drawing

sf::Font font;

void charge_font()
{
  if (!font.loadFromFile("font.otf")) {
    cout<<"The font could not be charged"<<endl;
    exit(0);
  }
}

void draw_text(sf::RenderWindow &window,int x,int y,string s,sf::Color color)
{
  sf::Text text;
  text.setString(s);
  text.setFont(font);
  text.setColor(color);
  text.setOrigin(sf::Vector2f(0,text.getLocalBounds().height/2.0));
  text.setScale(sf::Vector2f(0.5,0.5));
  //text.setScale(sf::Vector2f(float(ladoboton)/text.getLocalBounds().height,float(ladoboton)/text.getLocalBounds().height));
  text.setPosition(sf::Vector2f(x,y));
  window.draw(text);
}

void draw_text(sf::RenderWindow &window,int x,int y,string s)
{
  draw_text(window,x,y,s,sf::Color::White);
}

void draw_circle(sf::RenderWindow &window,point p,float r,sf::Color color,bool selected)
{
  sf::CircleShape circle;
  circle.setRadius(r);
  circle.setFillColor(color);
  circle.setOrigin(r,r);
  circle.setPosition(real(p),imag(p));
  if (selected) {
    circle.setOutlineThickness(1);
    circle.setOutlineColor(sf::Color::Red);
  }
  window.draw(circle);
}

void draw_polygon(sf::RenderWindow &window,vector<point> vp,sf::Color color,bool selected)
{
  sf::ConvexShape polygon;
  polygon.setPointCount(int(vp.size()));
  for (int i=0;i<int(vp.size());i++)
    polygon.setPoint(i,sf::Vector2f(real(vp[i]),imag(vp[i])));
  polygon.setFillColor(color);
  if (selected) {
    polygon.setOutlineThickness(1);
    polygon.setOutlineColor(sf::Color::Red);
  }
  window.draw(polygon);
}

int visible=1;

void draw_body(sf::RenderWindow &window,Body &b,bool selected)
{
  if (visible) {
    for (int i=0;i<int(b.vf.size());i++) {
      Fixture &f=b.vf[i];
      sf::Color color=f.owncolor?f.color:b.color;
      if (f.kind==CIRCLE) draw_circle(window,get_absolute_point(b,f.p),f.r,color,selected);
      else draw_polygon(window,get_absolute_points(b,f),color,selected);
    }
  }
  draw_circle(window,b.c,1,sf::Color::Red,false);
}

void draw_world(sf::RenderWindow &window,vector<Body> &vb,int ibkeys)
{
  window.clear(sf::Color::Black);
  draw_text(window,10,10,"DIRECTION: UP,DOWN,RIGHT,LEFT");
  draw_text(window,10,40,"MODE VEL/ACC: F1");
  draw_text(window,10,70,"BODY SELECT: F2");
  draw_text(window,10,100,"EXIT: ESC");
  for (int i=0;i<int(vb.size());i++)
    draw_body(window,vb[i],ibkeys==i);
  window.display();
} 


//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// run world

const int SCRWIDTH  = 600;
const int SCRHEIGHT = 600;
const double VELOCITY=40;
const double ACCELERATION=120;

void read_keys(int mode,point &a,point &v,sf::Keyboard::Key up,sf::Keyboard::Key down,sf::Keyboard::Key right,sf::Keyboard::Key left)
{
  if (mode==0) {
    v=point(0,0);
    if (sf::Keyboard::isKeyPressed(up))
      v+=point(0,-VELOCITY);
    if (sf::Keyboard::isKeyPressed(down))
      v+=point(0,VELOCITY);
    if (sf::Keyboard::isKeyPressed(right))
      v+=point(VELOCITY,0);
    if (sf::Keyboard::isKeyPressed(left))
      v+=point(-VELOCITY,0);
  } else {
    if (sf::Keyboard::isKeyPressed(up))
      a+=point(0,-ACCELERATION);
    if (sf::Keyboard::isKeyPressed(down))
      a+=point(0,ACCELERATION);
    if (sf::Keyboard::isKeyPressed(right))
      a+=point(ACCELERATION,0);
    if (sf::Keyboard::isKeyPressed(left))
      a+=point(-ACCELERATION,0);
  }
}

void run(sf::RenderWindow &window,World world)
{
  vector<Body> &vb=world.vb;
  for (int i=0;i<int(vb.size());i++)
    precompute_body_values(vb[i]);
  sf::Clock clock;
  int ibkeys=0;
  int mode=1;
  for (;;) {
    sf::Event event;
    while (window.pollEvent(event)) {
      switch (event.type) {
      case sf::Event::Closed:
	window.close();
	exit(0);
	break;
      case sf::Event::KeyPressed:
	if (event.key.code == sf::Keyboard::Escape) {
	  //window.close();
	  return;
	} else if (event.key.code == sf::Keyboard::F1) {
	  mode=(mode+1)%2;
	} else if (event.key.code == sf::Keyboard::F2) {
	  ibkeys=(ibkeys+1)%int(vb.size());
	  //} else if (event.key.code == sf::Keyboard::F3) {
	  //visible=(visible+1)%2;
	}
      case sf::Event::MouseButtonPressed:
      default:
	break;
      }
    }
    double delta=clock.restart().asSeconds();
    point v(0,0);
    point a(0,0);
    read_keys(mode,a,v,sf::Keyboard::Up,sf::Keyboard::Down,sf::Keyboard::Right,sf::Keyboard::Left);
    if (mode==0) vb[ibkeys].v=v;
    else vb[ibkeys].v+=delta*a;
    move_bodies(vb,delta);
    draw_world(window,vb,ibkeys);
  }
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Parsing of an input file with a world description

void print(Fixture f)
{
  string desp="      ";
  cout<<desp<<"FIXTURE"<<endl;
  desp+="  ";
  if (f.kind==CIRCLE) {
    cout<<desp<<"kind: CIRCLE"<<endl;
    cout<<desp<<"r: "<<f.r<<endl;
    cout<<desp<<"p: ";print(f.p);cout<<endl;
  } else {
    cout<<desp<<"kind: CONVEX"<<endl;
    cout<<desp<<"vp: ";
    for (int i=0;i<int(f.vp.size());i++)
      print(f.vp[i]);
    cout<<endl;
  }
  cout<<desp<<"d: "<<f.d<<endl;
  cout<<desp<<"f: "<<f.f<<endl;
  cout<<desp<<"res: "<<f.res<<endl;
  cout<<desp<<"owncolor: "<<f.owncolor<<endl;
}

void print(Body b)
{
  string desp="  ";
  cout<<desp<<"BODY"<<endl;
  desp+="  ";
  cout<<desp<<"v: "<<b.v<<endl;
  cout<<desp<<"w: "<<b.w<<endl;
  for (int i=0;i<int(b.vf.size());i++)
    print(b.vf[i]);
}

void print(World world)
{
  cout<<"WORLD"<<endl;
  cout<<"Description: "<<world.description<<endl;
  for (int i=0;i<int(world.vb.size());i++)
    print(world.vb[i]);
}

struct Token {
  string kind,text;
  double d;
  int line,column;
  Token(){}
  Token(double d,int line,int column):
    d(d),line(line),column(column) {kind="double";}
  Token(string kind,int line,int column):
    kind(kind),line(line),column(column) {d=0;}
  Token(string kind,string text,int line,int column):
    kind(kind),text(text),line(line),column(column) {d=0;}
};

set<string> keywords;
char arraykeywords[][80]={
  "description","v","w","vf",
  "r","p","vp","d","f","res","color",
  "Red","Blue","White","Green","Yellow",
  "{","}","[","]","(",")","//",":","\"",",",""};

void init_keywords()
{
  keywords=set<string> ();
  for (int i=0;string(arraykeywords[i])!="";i++)
    keywords.insert(arraykeywords[i]);
}

string read_until_end_of_line(string &s,int &is)
{
  string r;
  while (is<int(s.size()) and s[is]!='\n')
    r+=string(1,s[is++]);
  return r;
}

void read_double(string &s,int &is,int &isiniline,int &line,vector<Token> &vt)
{
  int nextis=is;
  int posdot=-1;
  while (nextis<int(s.size()) and ((s[nextis]>='0' and s[nextis]<='9') or
				   (s[nextis]=='-' and nextis==is) or
				   (posdot==-1 and s[nextis]=='.'))) {
    if (s[nextis]=='.') posdot=nextis;
    nextis++;
  }
  string text=s.substr(is,nextis-is);
  if (text[0]=='-' and (int(text.size())==1 or posdot==1))
    die("Parsing error line "+my_itos(line)+" column "+my_itos(nextis-isiniline+1)+
	": wrong double.");
  vt.push_back(Token(stodouble(text),line,is-isiniline+1));
  is=nextis;
}

void read_token(string &s,int &is,int &isiniline,int &line,vector<Token> &vt)
{
  if (s[is]=='\n') {
    is++;
    isiniline=is;
    line++;
  } else if (s[is]=='-' or (s[is]>='0' and s[is]<='9')) {
    read_double(s,is,isiniline,line,vt);
  } else {
    // Read from big to small string in order to avoid that a prefix of a possible
    // read keyword makes this keyword not considered.
    for (set<string>::reverse_iterator it=keywords.rbegin();it!=keywords.rend();it++) {
      string c=*it;
      if (int(s.size())-is>=int(c.size()) and s.substr(is,int(c.size()))==c) {
	if (c=="//") {
	  read_until_end_of_line(s,is);
	  if (is<int(s.size())) is++;
	  isiniline=is;
	  line++;
	  return;
	} else if (c=="\"") {
	  int isprev=is;
	  for (is++;is<int(s.size()) and s[is]!='"';is++)
	    if (s[is]=='\n')
	      die("Error line "+my_itos(line)+" column "+
		    my_itos(isprev-isiniline+1)+": unfinished string in the same line.");
	  if (is==int(s.size()))
	    die("Error line "+my_itos(line)+" column "+
		my_itos(isprev-isiniline+1)+": unfinished string in the same line.");
	  vt.push_back(Token(c,s.substr(isprev+1,is-isprev-1),line,isprev-isiniline+1));
	  is++;
	  return;
	}
	vt.push_back(Token(c,line,is-isiniline+1));
	is+=int(c.size());
	return;
      }
    }
    string pos=my_itos(is-isiniline+1);
    string err=read_until_end_of_line(s,is);
    die("Error line "+my_itos(line)+" column "+pos+
	": no correspondence is found for \""+err+"\".");
  }
}

void jump_white_spaces(string &s,int &is)
{
  while (is<int(s.size()) and (s[is]==' ' or s[is]=='\t')) is++;
}

void read_tokens(string &s,vector<Token> &vt)
{
  int is=0;
  int line=1;
  int isiniline=0;
  jump_white_spaces(s,is);
  while (is<int(s.size())) {
    read_token(s,is,isiniline,line,vt);
    jump_white_spaces(s,is);
  }
}

vector<Token> read_tokens(string s)
{
  init_keywords();
  vector<Token> vt;
  read_tokens(s,vt);
  return vt;
}


void check_kind(vector<Token> &vt,int &ivt,string t)
{
  if (ivt==int(vt.size()))
    die("Error: the end of the program was found while '"+t+"' was expected.");
  if (vt[ivt].kind!=t)
    die("Error line "+my_itos(vt[ivt].line)+" column "+my_itos(vt[ivt].column)+
	": we expected to see '"+t+"', but we found '"+vt[ivt].kind+"'.");
}

void jump_kind(vector<Token> &vt,int &ivt,string t)
{
  check_kind(vt,ivt,t);
  ivt++;
}

double parsing_double(vector<Token> &vt,int &ivt)
{
  check_kind(vt,ivt,"double");
  return vt[ivt++].d;
}

point parsing_point(vector<Token> &vt,int &ivt)
{
  jump_kind(vt,ivt,"(");
  double x=parsing_double(vt,ivt);
  jump_kind(vt,ivt,",");
  double y=parsing_double(vt,ivt);
  jump_kind(vt,ivt,")");
  return point(x,y);
}

void die_unexpected(vector<Token> &vt,int &ivt)
{
  if (ivt>=int(vt.size()))
    die("Error: The end of the input was reached unexpectedly");
  die("Error line "+my_itos(vt[ivt].line)+" column "+my_itos(vt[ivt].column)+": '"+vt[ivt].kind+
      "' was not expected.");
}

sf::Color parsing_color(vector<Token> &vt,int &ivt)
{
  if (ivt>=int(vt.size())) die_unexpected(vt,ivt);
  else if (vt[ivt].kind=="Red") {ivt++;return sf::Color::Red;}
  else if (vt[ivt].kind=="Green") {ivt++;return sf::Color::Green;}
  else if (vt[ivt].kind=="Blue") {ivt++;return sf::Color::Blue;}
  else if (vt[ivt].kind=="Yellow") {ivt++;return sf::Color::Yellow;}
  else if (vt[ivt].kind=="White") {ivt++;return sf::Color::White;}
  else die_unexpected(vt,ivt);
  return sf::Color::Black;
}

/*
  Fixture(double r,point p,double d,double f,double res,sf::Color color):
  Fixture(vector<point> vpin,double d,double f,double res,sf::Color color):d(d),f(f),res(res),colo
  Body(point v,double w,sf::Color color):v(v),w(w),color(color) {}
*/

Fixture parsing_fixture(vector<Token> &vt,int &ivt)
{
  Fixture f;
  jump_kind(vt,ivt,"{");
  while (ivt<int(vt.size()) and vt[ivt].kind!="}") {
    if (vt[ivt].kind=="r") {
      f.kind=CIRCLE;
      ivt++;
      jump_kind(vt,ivt,":");
      f.r=parsing_double(vt,ivt);
    } else if (vt[ivt].kind=="p") {
      f.kind=CIRCLE;
      ivt++;
      jump_kind(vt,ivt,":");
      f.p=parsing_point(vt,ivt);
    } else if (vt[ivt].kind=="d") {
      ivt++;
      jump_kind(vt,ivt,":");
      f.d=parsing_double(vt,ivt);
    } else if (vt[ivt].kind=="f") {
      ivt++;
      jump_kind(vt,ivt,":");
      f.f=parsing_double(vt,ivt);
    } else if (vt[ivt].kind=="res") {
      ivt++;
      jump_kind(vt,ivt,":");
      f.res=parsing_double(vt,ivt);
    } else if (vt[ivt].kind=="color") {
      ivt++;
      jump_kind(vt,ivt,":");
      f.owncolor=true;
      f.color=parsing_color(vt,ivt);
    } else if (vt[ivt].kind=="vp") {
      f.kind=CONVEX;
      ivt++;
      jump_kind(vt,ivt,":");
      jump_kind(vt,ivt,"[");
      while (ivt<int(vt.size()) and vt[ivt].kind!="]")
	f.vp.push_back(parsing_point(vt,ivt));
      jump_kind(vt,ivt,"]");
    } else die_unexpected(vt,ivt);
  }
  jump_kind(vt,ivt,"}");
  return f;
}

Body parsing_body(vector<Token> &vt,int &ivt)
{
  Body b;
  jump_kind(vt,ivt,"{");
  while (ivt<int(vt.size()) and vt[ivt].kind!="}") {
    if (vt[ivt].kind=="v") {
      ivt++;
      jump_kind(vt,ivt,":");
      b.v=parsing_point(vt,ivt);
    } else if (vt[ivt].kind=="w") {
      ivt++;
      jump_kind(vt,ivt,":");
      b.w=parsing_double(vt,ivt);
    } else if (vt[ivt].kind=="vf") {
      ivt++;
      jump_kind(vt,ivt,":");
      jump_kind(vt,ivt,"[");
      while (ivt<int(vt.size()) and vt[ivt].kind!="]")
	b.vf.push_back(parsing_fixture(vt,ivt));
      jump_kind(vt,ivt,"]");
    } else if (vt[ivt].kind=="color") {
      ivt++;
      jump_kind(vt,ivt,":");
      b.color=parsing_color(vt,ivt);
    } else die_unexpected(vt,ivt);
  }
  jump_kind(vt,ivt,"}");
  return b;
}

World parsing_world(vector<Token> vt)
{
  int ivt=0;
  World world;
  while (ivt<int(vt.size())) {
    if (vt[ivt].kind=="description") {
      jump_kind(vt,ivt,"description");
      jump_kind(vt,ivt,":");
      check_kind(vt,ivt,"\"");
      world.description=vt[ivt].text;
      ivt++;
    } else world.vb.push_back(parsing_body(vt,ivt));
  }
  if (int(world.vb.size())==0)
    die("Error: the world must have at least one body");
  return world;
}

World read_world(string filename)
{
  cout<<"Parsing world file \""<<filename<<"\""<<endl;
  return parsing_world(read_tokens(read_file(filename)));
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// main

vector<World> read_world_files()
{
  istringstream mycin(read_file("worldfiles"));
  string filename;
  vector<World> vw;
  while (mycin>>filename)
    vw.push_back(read_world(filename));
  return vw;
}

int main()
{
  vector<World> vw=read_world_files();
  sf::RenderWindow window;
  window.create(sf::VideoMode(SCRWIDTH,SCRHEIGHT),"Inertial momentum");
  charge_font();
  int selection=0;
  for (;;) {
    sf::Event event;
    while (window.pollEvent(event)) {
      switch (event.type) {
      case sf::Event::Closed:
	window.close();
	exit(0);
	break;
      case sf::Event::KeyPressed:
	if (event.key.code == sf::Keyboard::Escape) {
	  window.close();
	  exit(0);
	} else if (event.key.code == sf::Keyboard::Return) {
	  run(window,vw[selection]);
	} else if (event.key.code == sf::Keyboard::Up) {
	  selection=(selection-1+int(vw.size()))%(int(vw.size()));
	} else if (event.key.code == sf::Keyboard::Down) {
	  selection=(selection+1)%(int(vw.size()));
	}
	break;
      case sf::Event::MouseButtonPressed:
      default:
	break;
      }
    }
    window.clear(sf::Color::Black);
    draw_text(window,50,100,"Selection keys: UP,DOWN,ENTER,ESC");
    for (int i=0;i<int(vw.size());i++)
      draw_text(window,50,150+30*i,vw[i].description,selection==i?(sf::Color::Red):(sf::Color::White));
    window.display();
  }
}
