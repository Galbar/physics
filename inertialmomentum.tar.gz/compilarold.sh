g++ -Wall  -I. inertialmomentum.1.cc -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -o inertialmomentum.1
g++ -Wall  -I. inertialmomentum.2.cc -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -o inertialmomentum.2
g++ -Wall  -I. inertialmomentum.3.cc -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -o inertialmomentum.3
g++ -Wall  -I. inertialmomentum.4.cc -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -o inertialmomentum.4
g++ -Wall  -I. inertialmomentum.5.cc -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -o inertialmomentum.5
g++ -Wall  -I. inertialmomentum.6.cc -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio -o inertialmomentum.6
