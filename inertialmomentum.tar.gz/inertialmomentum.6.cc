#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Graphics/Shape.hpp>
#include <SFML/Graphics/RectangleShape.hpp>

#include <iostream>
//#include <complex>
#include <cmath>
#include <fstream>
#include <cstdlib>
#include <queue>
#include <sstream>
#include <algorithm>

//#include "Box2D/Box2D.h"


using namespace std;

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Basic functions

typedef long long int ll;

double error=1e-5;

void maximize(double &a,double b)
{
  a=max(a,b);
}

void minimize(double &a,double b)
{
  a=min(a,b);
}

void die(string s)
{
  cout<<s<<endl;
  exit(0);
}

double sq(double x)
{
  return x*x;
}

int sign(double x)
{
  if (x>0) return 1;
  if (x<0) return -1;
  return 0;
}

int my_stoi(string s)
{
  istringstream ci(s);
  string aux;
  ci>>aux;
  s=aux;
  int r=0;
  for (int i=0;i<int(s.size());i++) {
    if (not (s[i]>='0' and s[i]<='9'))
      die("Error: '"+s+"' is not int.");
    r=r*10+s[i]-'0';
  }
  return r;
}

string my_itos(int x)
{
  string s(1,char(x%10+'0'));
  while (x>=10) {
    x/=10;
    s=string(1,char(x%10+'0'))+s;
  }
  return s;
}

double stodouble(string s)
{
  istringstream mycin(s);
  double x;
  mycin>>x;
  return x;
}

string read_file(string filename)
{
  string contents;
  ifstream fcontents(filename.c_str());
  if (not fcontents.is_open())
    die("Error: could not open '"+filename+"'.");
  string s;
  getline(fcontents,contents);
  while (getline(fcontents,s))
    contents+='\n'+s;
  fcontents.close();
  return contents;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Definition of Points

//typedef complex<double> Point;

struct Point {
  double x,y;
  Point() {}
  Point(double x,double y):x(x),y(y) {}

  Point &operator+=(const Point &p) {
    x+=p.x;
    y+=p.y;
    return *this;
  }

  Point &operator-=(const Point &p) {
    x-=p.x;
    y-=p.y;
    return *this;
  }

  Point &operator*=(const double &a) {
    x*=a;
    y*=a;
    return *this;
  }

  Point &operator/=(const double &a) {
    x/=a;
    y/=a;
    return *this;
  }
};

inline Point operator+(const Point &p1,const Point &p2)
{
  return Point(p1.x+p2.x,p1.y+p2.y);
}

inline Point operator-(const Point &p1,const Point &p2)
{
  return Point(p1.x-p2.x,p1.y-p2.y);
}

inline Point operator*(const Point &p1,const Point &p2)
{
  return Point(p1.x*p2.x-p1.y*p2.y,p1.x*p2.y+p1.y*p2.x);
}

inline Point operator*(double a,const Point &p)
{
  return Point(a*p.x,a*p.y);
}

inline Point operator*(const Point &p,double a)
{
  return Point(a*p.x,a*p.y);
}

inline Point operator/(const Point &p,double a)
{
  return Point(p.x/a,p.y/a);
}

Point my_polar(double r,double a)
{
  return Point(r*cos(a),r*sin(a));
}

void print(Point p)
{
  cout<<"("<<p.x<<","<<p.y<<")";
}

void print(vector<Point> v)
{
  for (int i=0;i<int(v.size());i++)
    print(v[i]);
}

double prod_esc(const Point &p1,const Point &p2)
{
  return p1.x*p2.x+p1.y*p2.y;
}

double norm(const Point &p)
{
  return prod_esc(p,p);
}

double abs(const Point &p)
{
  return sqrt(norm(p));
}

double prod_vec(const Point &p1,const Point &p2)
{
  return p1.x*p2.y-p1.y*p2.x;
}

Point unitary(const Point &p)
{
  return p/abs(p);
}

double circle_area(double r)
{
  return M_PI*sq(r);
}

// Approximate computation of inertial momentum of a circle with center c,
// radious r, and density d, with respect to a reference position ref,
// based on approximating integration with
// small squares (0.1*r)x(0.1*r) (with area 0.01*r*r).
double circle_inertia(Point c,double r,double d,Point ref)
{
  double I=0;
  for (int x=-10;x<=10;x++) {
    for (int y=-10;y<=10;y++) {
      Point desp(r*double(x)/10,r*double(y)/10);
      if (abs(desp)<r)
	I+=norm(c+desp-ref)*d*sq(0.1*r);
    }
  }
  return I;
}

double convex_oriented_area(vector<Point> vp)
{
  double a=0;
  for (int i=1;i<int(vp.size())-1;i++)
    a+=prod_vec(vp[i]-vp[0],vp[i+1]-vp[0])/2.0;
  return a;
}

double convex_area(vector<Point> vp)
{
  return abs(convex_oriented_area(vp));
}

Point triangle_center(Point p1,Point p2,Point p3)
{
  return (p1+p2+p3)/3.0;
}

double triangle_area(Point p1,Point p2,Point p3)
{
  return abs(prod_vec(p2-p1,p3-p1)/2.0);
}

// Computes the inertial momentum of a triangle with respect
// to a position c, with the incorrect assumption that
// all its mass was concentrated on its center of masses,
// although it is uniformly distributed with density d,
// in order to make just an approximation.
double basic_triangle_inertia(Point p1,Point p2,Point p3,double d,Point c)
{
  return norm(triangle_center(p1,p2,p3)-c)*d*triangle_area(p1,p2,p3);
}

// Approximate computation of inertial momentum of
// a triangle with density d, and with respect to a position c,
// based on approximating integration. Basically, it divides
// the triangle in small triangles for which the
// previous basic_triangle_inertia function is computed.
double triangle_inertia(Point p1,Point p2,Point p3,double d,Point c)
{
  double I=0;
  for (int i=0;i<10;i++) {
    double x=i/10.0;
    double nextx=(i+1)/10.0;
    Point pa=(1.0-x)*p1+x*p2;
    Point pb=(1.0-nextx)*p1+nextx*p2;
    for (int j=0;j<10;j++) {
      double y=j/10.0;
      double nexty=(j+1)/10.0;
      Point pc=pa*(1.0-y)+y*p3;
      Point pd=pb*(1.0-y)+y*p3;
      Point pe=pa*(1.0-nexty)+nexty*p3;
      Point pf=pb*(1.0-nexty)+nexty*p3;
      I+=basic_triangle_inertia(pc,pd,pe,d,c)+basic_triangle_inertia(pd,pf,pe,d,c);
    }
  }
  return I;
}

// Approximate computation of inertial momentum of
// a convex based on approximating integration.
double convex_inertia(vector<Point> &vp,double d,Point c)
{
  double I=0;
  for (int i=1;i<int(vp.size())-1;i++)
    I+=triangle_inertia(vp[0],vp[i],vp[i+1],d,c);
  return I;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Static data structures


// For optimizing and avoiding the use of dynamic memory in some critical cases,
// we define some data structures that work internally with static memory.

// These are the constants that bound the static memory. The TWICELIMIT is necessary
// in the case of the tree, as internal nodes of the tree multiply by 2 the size of the kept data.
const int LIMIT=1<<20;
const int TWICELIMIT=1<<21;

// We define a stack of natural numbers.
// The stack does not add an element already contained in it, i.e. it always contains
// distinct elements.
struct Stack {
  int numelems;
  int pos2elem[LIMIT];
  int elem2pos[LIMIT];
  Stack() {
    numelems=0;
  }
  void reset() {
    numelems=0;
  };
  void push(int e)
  {
    if (LIMIT<=e) die("Push element out of range in stack operation");
    if (elem2pos[e]<numelems and pos2elem[elem2pos[e]]==e) return;
    if (LIMIT<=numelems) die("Push out of range in stack operation");
    pos2elem[numelems]=e;
    elem2pos[e]=numelems;
    numelems++;
  }
  int pop() {
    if (numelems==0) return 0;
    return pos2elem[--numelems];
  }
  bool empty() {
    return numelems==0;
  }
};

// We define a multi-counter associated to natural numbers, that can be reset to 0 for all naturals,
// and one can increment (by 1) or consult the counter of a concrete natural number.
struct Counter {
  ll time;
  ll elem2time[LIMIT];
  int elem2counter[LIMIT];
  Counter() {
    time=1;
    for (int i=0;i<LIMIT;i++)
      elem2time[i]=0;
  }
  void reset() {
    time++;
  }
  // Auxiliary function to reset a counter value if it is out of time.
  void make_counter_in_time(int e)
  {
    if (elem2time[e]!=time) {
      elem2time[e]=time;
      elem2counter[e]=0;
    }    
  }
  int get_counter(int e) {
    if (LIMIT<=e) die("Get counter out of range.");
    make_counter_in_time(e);
    return elem2counter[e];
  }
  void increment_counter(int e) {
    if (LIMIT<=e) die("Increment counter out of range.");
    make_counter_in_time(e);
    elem2counter[e]++;
  }
};

// We define an element of list structure to traverse a list. Perhaps
// the definition and use of iterators would be preferable here.
// The constructor without parameters sets the values to be the ones that
// mark the end of a list by default. Thus, an expression le!=ListElem() checks if le
// is not the end of a list.
struct ListElem {
  int value;
  int internalindex;
  ListElem() {value=-1;internalindex=-1;}
  ListElem(int value,int internalindex):value(value),internalindex(internalindex) {}
};

bool operator!=(ListElem e1,ListElem e2)
{
  return e1.value!=e2.value or e1.internalindex!=e2.internalindex;
}

// We define a map from naturals to list of naturals.
// It will be used to ease the representation of a graph, but also to represent
// a mapping from position identifiers to list of AABB ids during the computation
// of contacts of AABB's.
struct IntToListInt {
  ll time;
  ll dom2time[LIMIT];
  int dom2first[LIMIT];
  int dom2last[LIMIT];
  int numimag;
  int imag2next[LIMIT];
  int imag2value[LIMIT];
  IntToListInt() {
    time=1;
    numimag=0;
    for (int i=0;i<LIMIT;i++)
      dom2time[i]=0;
  }
  void reset() {
    time++;
    numimag=0;
  }
  void insert(int dom,int val)
  {
    if (LIMIT<=dom) die("Insert element in list out of range.");
    if (LIMIT<=numimag) die("Amount of inserted elements in list out of range.");
    int imag=numimag++;
    if (dom2time[dom]!=time) {
      dom2time[dom]=time;
      dom2first[dom]=dom2last[dom]=imag;
    } else {
      imag2next[dom2last[dom]]=imag;
      dom2last[dom]=imag;
    }
    imag2value[imag]=val;
    imag2next[imag]=-1;
  }
  ListElem begin(int dom)
  {
    if (LIMIT<=dom) die("Begin element in list out of range.");
    if (dom2time[dom]!=time) return ListElem();
    int imag=dom2first[dom];
    return ListElem(imag2value[imag],imag);
  }
  ListElem next(ListElem le)
  {
    int imag=imag2next[le.internalindex];
    if (imag==-1) return ListElem();
    return ListElem(imag2value[imag],imag);
  }
};

// We define a map from points to natural numbers that essentially
// identifies points with natural numbers (positions), ordered by x and next by y,
// and allows to compute the
// minimum and maximum position for a given x-coordinate.
// For simplicity, repetitions don't care, but they could be removed in
// a future implementation change.
// In the use of this data structure, for efficientcy it is convenient
// to proceed in the following order: start by reset, next
// insert all the points, and finally make all the queries.

bool smaller_point(Point p1,Point p2)
{
  double x1=p1.x;
  double x2=p2.x;
  if (x1<x2) return true;
  if (x1>x2) return false;
  return p1.y<p2.y;
}

struct Map {
  int numpoints;
  Point vp[LIMIT];
  bool ordered;
  void reset() {
    numpoints=0;
  }
  void insert(Point p) {
    if (LIMIT<=numpoints) die("Map insertion out of range");
    vp[numpoints++]=p;
    ordered=false;
  }
  // Internal function that makes the sort if necessary.
  void my_sort() {
    if (ordered) return;
    sort(vp,vp+numpoints,smaller_point);
    ordered=true;
  }
  // getpos assumes that p is already in vp.
  int getpos(Point p) {
    my_sort();
    int inf=0,sup=numpoints;
    while (inf+1<sup) {
      int med=(inf+sup)/2;
      if (smaller_point(p,vp[med])) sup=med;
      else inf=med;
    }
    return inf;
  }
  // getposinf assumes that a point with x is already in vp,
  // and returns the corresponding minimum position among them.
  int getposinf(double x) {
    my_sort();
    int inf=-1,sup=numpoints-1;
    while (inf+1<sup) {
      int med=(inf+sup)/2;
      if (vp[med].x<x) inf=med;
      else sup=med;
    }
    return sup;
  }
  // getpossup assumes that a point with x is already in vp,
  // and returns the corresponding maximum position among them.
  int getpossup(double x) {
    my_sort();
    int inf=0,sup=numpoints;
    while (inf+1<sup) {
      int med=(inf+sup)/2;
      if (x<vp[med].x) sup=med;
      else inf=med;
    }
    return inf;
  }
};

// We define a data structure Tree that represents a map from positions (naturals) to doubles,
// and makes easy to find, for a given position pos and a double d, the first
// position pos'>=pos with a double d'<=d.
// Several insertions of doubles in the same position keep the minimum among them.
struct Tree {
  int time;
  int pos2time[TWICELIMIT];
  double minimum[TWICELIMIT];
  Tree() {
    time=1;
    for (int i=0;i<TWICELIMIT;i++)
      pos2time[i]=0;
  }
  void reset() {
    time++;
  }
  void insert(int pos,double d)
  {
    pos+=LIMIT;
    if (pos2time[pos]!=time) {
      pos2time[pos]=time;
      minimum[pos]=d;
    } else minimize(minimum[pos],d);
    while (pos>1) {
      pos/=2;
      pos2time[pos]=time;
      if (pos2time[2*pos]!=time) minimum[pos]=minimum[2*pos+1];
      else if (pos2time[2*pos+1]!=time) minimum[pos]=minimum[2*pos];
      else minimum[pos]=min(minimum[2*pos],minimum[2*pos+1]);
    }
  }
  int next_pos_under(int pos,double d)
  {
    pos+=LIMIT;
    if (pos2time[pos]==time and minimum[pos]<=d) return pos-LIMIT;
    while (pos>1) {
      if (pos%2==0 and pos2time[pos+1]==time and minimum[pos+1]<=d) {
	pos++;
	while (pos<LIMIT)
	  if (pos2time[2*pos]==time and minimum[2*pos]<=d) pos=2*pos;
	  else pos=2*pos+1;
	return pos-LIMIT;
      }
      pos/=2;
    }
    return -1;
  }
};

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Definition and initialization of Bodies.

struct Body;

// Each fixture is either a circle or a convex polygon.
const int CIRCLE=1;
const int CONVEX=2;
struct Fixture {
  int kind; // CIRCLE or CONVEX.
  Body *b;
  double r; // radious (only for circles)
  Point p; // position (only for circles)
  vector<Point> vp; // positions (only for convex polygons)
  double d; // density
  double f; // friction
  double res; // restitution
  bool owncolor; // If false, the body color is taken
  sf::Color color; // surrounding color
  Fixture() {kind=CIRCLE;r=1;p=Point(0,0);d=1;f=0;res=0.5;owncolor=false;}
  Fixture(double r,Point p,double d,double f,double res,sf::Color color):
    r(r),p(p),d(d),f(f),res(res),color(color) {
    kind=CIRCLE;
  }
  // vp must represent a convex polygon as a list of clock-wise or counter-clock-wise points.
  Fixture(vector<Point> vpin,double d,double f,double res,sf::Color color):d(d),f(f),res(res),color(color) {
    kind=CONVEX;
    vp=vpin;
    if (convex_oriented_area(vp)<0)
      reverse(vp.begin(),vp.end());
  }
};

// Each body is either dynamic or static.
const int DYNAMIC=0;
const int STATIC=1;
struct Body {
  int kind; // DYNAMIC or STATIC
  int id; // Its position in the array of bodies. Just for optimizing the graph bodies-contacts.
  Point c; // mass center
  double rot; // rotation w.r.t. center
  Point v; // linear velocity
  double w; // angular velocity
  double I; // inertial momentum
  double m; // mass
  vector<Fixture> vf;
  sf::Color color; // Interior color of each fixture.
  Body() {kind=DYNAMIC;v=Point(0,0);w=0;color=sf::Color::White;}
  Body(Point v,double w,sf::Color color):v(v),w(w),color(color) {}
};

struct World {
  string description;
  vector<Body> vb;
};

Point get_absolute_point(Body &b,Point p)
{
  return b.c+my_polar(1.0,b.rot)*p;
}

Point get_absolute_point(Fixture &f)
{
  return get_absolute_point(*f.b,f.p);
}

vector<Point> get_absolute_points(Fixture &f)
{
  vector<Point> vp;
  for (int j=0;j<int(f.vp.size());j++)
    vp.push_back(get_absolute_point(*f.b,f.vp[j]));
  return vp;
}

double compute_mass(Fixture &f)
{
  return f.d*(f.kind==CIRCLE?circle_area(f.r):convex_area(f.vp));
}

void compute_mass(Body &b)
{
  b.m=0;
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++)
    b.m+=compute_mass(vf[i]);
}

Point compute_mass_sum_vector(Fixture &f)
{
  if (f.kind==CIRCLE)
    return compute_mass(f)*f.p;
  vector<Point> &vp=f.vp;
  Point c(0,0);
  for (int i=1;i<int(vp.size())-1;i++)
    c+=f.d*triangle_area(vp[0],vp[i],vp[i+1])*triangle_center(vp[0],vp[i],vp[i+1]);
  return c;
}

void compute_mass_center(Body &b)
{  
  b.c=Point(0,0);
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++)
    b.c+=compute_mass_sum_vector(vf[i]);
  b.c/=b.m;
}

// Approximate computation of inertial momentum of
// a Fixture with respect to a position c.
double compute_inertia(Fixture f,Point c)
{
  return f.kind==CIRCLE?circle_inertia(f.p,f.r,f.d,c):convex_inertia(f.vp,f.d,c);
}

// Approximate computation of inertial momentum of a Body
// with respect to its mass center.
void compute_inertia(Body &b)
{
  b.I=0;
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++)
    b.I+=compute_inertia(vf[i],b.c);
}

void make_positions_relative_to_mass_center(Body &b)
{
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++) {
    Fixture &f=vf[i];
    if (f.kind==CIRCLE) f.p-=b.c;
    else {
      vector<Point> &vp=f.vp;
      for (int j=0;j<int(vp.size());j++)
	vp[j]-=b.c;
    }
  }
}

void orient_polygons(Body &b)
{
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++) {
    Fixture &f=vf[i];
    if (f.kind==CONVEX) {
      vector<Point> &vp=f.vp;
      if (convex_oriented_area(vp)<0)
	reverse(vp.begin(),vp.end());
    }
  }
}

void init_pointers_to_body(Body &b)
{
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++)
    vf[i].b=&b;
}

// This function assumes that the Fixtures of b have the positions
// initialized as absolute coordinates, and all the rest of atributes initialized as well.
// The function computes the total mass, mass center, inertial momentum
// of the body, and make the positions of the fixtures relative to
// the mass center. It initializes the rotation to 0, and assumes
// that the linear and angular velocities are already initialized,
void precompute_body_values(Body &b)
{
  compute_mass(b);
  compute_mass_center(b);
  compute_inertia(b);
  make_positions_relative_to_mass_center(b);
  orient_polygons(b);
  init_pointers_to_body(b);
  b.rot=0;
}

void precompute_world_values(World &world)
{
  vector<Body> &vb=world.vb;
  for (int i=0;i<int(vb.size());i++) {
    vb[i].id=i;
    precompute_body_values(vb[i]);
  }
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Definition and resolution of contacts

struct Contact {
  Point p;
  Point n; // normal outgoing from b1
  Body *b1;
  Body *b2;
  double projection; // negation of penetration.
  double res; // restitution
  double f; // friction
};

/*
bool operator<(Contact c1,Contact c2)
{
  return c1.projection<c2.projection;
}

struct Resolution {
  Body *b;
  Point p;
  Point impulse;
  Resolution() {}
  Resolution(Body *b,Point p,Point impulse):b(b),p(p),impulse(impulse) {}
};
*/

void apply_impulse(Body &b,Point p,Point impulse)
{
  b.v+=impulse/b.m;
  b.w+=prod_vec(p-b.c,impulse)/b.I;
}

Point get_velocity(Body &b,Point p)
{
  return b.v+b.w*(Point(0,1)*(p-b.c));
}

bool compute_resolution(Contact con)
{
  Point p=con.p;
  Point n=con.n;
  Body &b1=*con.b1;
  Body &b2=*con.b2;
  if (b1.kind==STATIC and b2.kind==STATIC) return false;
  double res=con.res;
  Point v1=b1.kind==DYNAMIC?get_velocity(b1,p):Point(0,0);
  Point v2=b2.kind==DYNAMIC?get_velocity(b2,p):Point(0,0);
  Point v21=v2-v1;
  if (prod_esc(v21,n)>=0) return false;
  if (b1.kind==DYNAMIC and b2.kind==DYNAMIC) {
    double factor=-(1+res)*prod_esc(v21,n)/
      (1.0/b1.m+1.0/b2.m+sq(prod_vec(p-b1.c,n))/b1.I+sq(prod_vec(p-b2.c,n))/b2.I);
    apply_impulse(b1,p,(-factor)*n);
    apply_impulse(b2,p,factor*n);
  } else if (b1.kind==DYNAMIC) {//b2.kind==STATIC
    double factor=-(1+res)*prod_esc(v21,n)/
      (1.0/b1.m+sq(prod_vec(p-b1.c,n))/b1.I);
    apply_impulse(b1,p,(-factor)*n);
  } else {//b1.kind==STATIC and b2.kind==DYNAMIC
    double factor=-(1+res)*prod_esc(v21,n)/
      (1.0/b2.m+sq(prod_vec(p-b2.c,n))/b2.I);
    apply_impulse(b2,p,factor*n);
  }
  return true;
}

/*
void resolve_contacts(vector<Contact> vc)
{
  for (int paso=0;paso<20;paso++) {
    bool found=false;
    for (int i=0;i<int(vc.size()) and not found;i++) {
      vector<Resolution> vr=compute_resolution(vc[i]);
      if (int(vr.size())>0) {
	found=true;
	for (int i=0;i<int(vr.size());i++) {
	  Resolution &r=vr[i];
	  apply_impulse(*r.b,r.p,r.impulse);
	}
      }
    }
    if (not found) return;
  }
}
*/

// The contacts graph keeps all contacts, and solve and propagate them.
struct ContactsGraph {
  // Stack Counter ListElem IntToListInt
  int numcontacts;
  Contact vc[LIMIT];
  Stack contactid_stack,bodyid_stack;
  Counter contactid_counter;
  IntToListInt bodyid2contactsid;
  int limit_counter; // How many times each contact is solved during the propagation of solve.
  
  void reset() {
    contactid_stack.reset();
    bodyid_stack.reset();
    contactid_counter.reset();
    bodyid2contactsid.reset();
    numcontacts=0;
    limit_counter=5;
  }
  void insert(Contact con) {
    if (LIMIT<=numcontacts) die("Insert contact out of range");
    int contactid=numcontacts++;
    vc[contactid]=con;
    contactid_stack.push(contactid);
    int bodyid1=con.b1->id;
    int bodyid2=con.b2->id;
    bodyid2contactsid.insert(bodyid1,contactid);
    bodyid2contactsid.insert(bodyid2,contactid);
  }
  void solve() {
    while (not contactid_stack.empty()) {
      while (not contactid_stack.empty()) {
	int contactid=contactid_stack.pop();
	contactid_counter.increment_counter(contactid);
	Contact &con=vc[contactid];
	if (compute_resolution(con)) {
	  bodyid_stack.push(con.b1->id);
	  bodyid_stack.push(con.b2->id);
	}
      }
      while (not bodyid_stack.empty()) {
	int bodyid=bodyid_stack.pop();
	for (ListElem le=bodyid2contactsid.begin(bodyid);le!=ListElem();le=bodyid2contactsid.next(le)) {
	  int contactid=le.value;
	  if (contactid_counter.get_counter(contactid)<limit_counter)
	    contactid_stack.push(contactid);
	}
      }
    }
  }
};

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Detection of contacts between AABBs in time nlogn.

struct AABB {
  Fixture *f;
  double xmin,ymin,xmax,ymax;
  AABB() {}
  AABB(Fixture *f,double xmin,double ymin,double xmax,double ymax):
    f(f),xmin(xmin),ymin(ymin),xmax(xmax),ymax(ymax) {}
};

AABB get_aabb(Fixture &f)
{
  if (f.kind==CIRCLE) {
    Point c=get_absolute_point(f);
    double x=c.x;
    double y=c.y;
    double r=f.r;
    return AABB(&f,x-r,y-r,x+r,y+r);
  }
  vector<Point> &vp=f.vp;
  Point p=get_absolute_point(*f.b,vp[0]);
  AABB aabb(&f,p.x,p.y,p.x,p.y);
  for (int i=1;i<int(vp.size());i++) {
    p=get_absolute_point(*f.b,vp[i]);
    minimize(aabb.xmin,p.x);
    minimize(aabb.ymin,p.y);
    maximize(aabb.xmax,p.x);
    maximize(aabb.ymax,p.y);
  }
  return aabb;
}

struct AABBReference {
  int aabb_id;
  double y;
  AABBReference() {}
  AABBReference(int aabb_id,double y):aabb_id(aabb_id),y(y) {}
};

bool operator<(AABBReference aabbr1,AABBReference aabbr2)
{
  return aabbr1.y<aabbr2.y;
}

// The AABBManager data structure will receive severall AABBs.
// At some point, it will be demmanded to decide which of such AABBs
// intersect, and it will do that in nlogn. With this goal,
// it will create two AABBReferences for each AABB, one for
// y=ymax, and one for y=ymin. It will sort all the AABBReferences
// by y's, and will traverse them from the highest to the smallest.

// For each AABBReference with an y=ymax of a certain aabb of a certain fixture f,
// this aabb has their corresponding xmin,xmax,ymin, and the manager will
// introduce the two points pmin=(xmin,ymin),pmax=(xmax,ymin) into a Tree
// In fact, the Tree maps positions to doubles, thus, before insertion
// into the tree, the manager will obtain position identifiers posmin,posmax
// of pmin,pmax, respectively (using a Map structure), and will map (using the Tree)
// those posmin,posmax to ymin. This way, the Tree sets that at those positions
// there are points with height ymin. Also, the manager will keep (in an
// IntToListInt) that in such positions there is the fixture f.

// For each AABBReference with an y=ymin of a certain aabb of a certain fixture f',
// this aabb has their corresponding xmin,xmax,ymax, and the manager will
// use the Map to obtain the minimum posmin holding that the kept point has x=xmin,
// and to obtain the maximum posmax holding that the kept point has x=xmax.
// Next, the manager will use the Tree and the ListToListInt to obtain all
// the fixtures f previously introduced, and between posmin and posmax and with
// height smaller than or equal to ymax. This way, it concludes that <f,f'> intersect.

ll globaltime=0;

struct AABBManager {
  int numaabb;
  AABB vaabb[LIMIT];
  AABBReference vaabbr[LIMIT];
  IntToListInt pos2list_of_aabbid;
  Map point2pos;
  Tree pos2minimum;
  int numsol;
  pair<Fixture *,Fixture *> sol[LIMIT];

  void reset() {
    numaabb=0;
  }
  // Internal function to construct the intersections of AABBs.
  void add_to_sol(Fixture *f1,Fixture *f2)
  {
    if (f1->b==f2->b) return;
    if (f1->b->kind==STATIC and f2->b->kind==STATIC) return;
    if (LIMIT<=numsol) die("Overflow in add solution in AABBManager");
    //cout<<"add contact "<<(f1->b->id)<<" "<<(f2->b->id)<<endl;
    sol[numsol++]=pair<Fixture *,Fixture *> (f1,f2);
  }
  void insert(Fixture &f) {
    if (LIMIT<=numaabb) die("Overflow in insert in AABBManager");
    AABB aabb=get_aabb(f);
    aabb.xmin-=error;
    aabb.ymin-=error;
    aabb.xmax+=error;
    aabb.ymax+=error;
    vaabb[numaabb++]=aabb;
  }

  void solve() {
    numsol=0;
    pos2list_of_aabbid.reset();
    point2pos.reset();
    pos2minimum.reset();
    int numaabbr=0;
    // We create the two aabbreferences for each aabb, and map each inferior point
    // of each aabb to a natural number (the position identifier).
    // Positions preserve the usual order of points (first x, and next y).
    for (int i=0;i<numaabb;i++) {
      AABB &aabb=vaabb[i];
      vaabbr[numaabbr++]=AABBReference(i,aabb.ymax);
      vaabbr[numaabbr++]=AABBReference(i,aabb.ymin);
      point2pos.insert(Point(aabb.xmin,aabb.ymin));
      //point2pos.insert(Point(aabb.xmin,aabb.ymax));
      point2pos.insert(Point(aabb.xmax,aabb.ymin));
      //point2pos.insert(Point(aabb.xmax,aabb.ymax));
    }
    // We sort the aabbreferences by y.
    sort(vaabbr,vaabbr+numaabbr);
    // We traverse the aabbreferences from big to small ys.
    for (int i=numaabbr-1;i>=0;i--) {
      AABBReference &aabbr=vaabbr[i];
      AABB &aabb=vaabb[aabbr.aabb_id];
      Fixture *f=aabb.f;
      if (aabb.ymax==aabbr.y) {
	int posxmin=point2pos.getpos(Point(aabb.xmin,aabb.ymin));
	pos2minimum.insert(posxmin,aabb.ymin);
	pos2list_of_aabbid.insert(posxmin,aabbr.aabb_id);
	int posxmax=point2pos.getpos(Point(aabb.xmax,aabb.ymin));
	pos2minimum.insert(posxmax,aabb.ymin);
	pos2list_of_aabbid.insert(posxmax,aabbr.aabb_id);
      } else {
	int posmax=point2pos.getpossup(aabb.xmax);
	for  (int pos=pos2minimum.next_pos_under(point2pos.getposinf(aabb.xmin),aabb.ymax);
	      pos!=-1 and pos<=posmax; pos=pos2minimum.next_pos_under(pos+1,aabb.ymax)) {
	  for (ListElem le=pos2list_of_aabbid.begin(pos);le!=ListElem();le=pos2list_of_aabbid.next(le)) {
	    int aabb_id=le.value;
	    add_to_sol(f,vaabb[aabb_id].f);
	  }
	}
      }
    }
    // Finally we remove the repeated pairs from sol.
    int nextnumsol=0;
    for (int i=0;i<numsol;i++) {
      // Put both fixtures of each pair in order, so that we
      // can compare disequality of pairs directly by !=.
      if (sol[i].first>sol[i].second) swap(sol[i].first,sol[i].second);
      if (nextnumsol==0 or sol[i]!=sol[nextnumsol-1]) sol[nextnumsol++]=sol[i];
    }
    numsol=nextnumsol;

    globaltime++;
    if (numsol>0) cout<<"Numsol "<<numsol<<" globaltime "<<globaltime<<endl;
  }
};

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Detection of contacts between Fixtures.

struct ContactSide {
  Point p,p1,p2; // p used for circle-convex, p1,p2 used for convex-convex.
  Point n;
  double projection; // Negated of penetration
};

bool operator<(ContactSide cs1,ContactSide cs2)
{
  return cs1.projection<cs2.projection;
}

ContactSide compute_min_projection_contact_side(Point p1,Point p2,vector<Point> &v)
{
  ContactSide cs;
  cs.p1=p1;
  cs.p2=p2;
  cs.n=unitary((p2-p1)*Point(0,-1));
  cs.projection=prod_esc(cs.n,v[0]-cs.p1);
  for (int i=1;i<int(v.size());i++)
    cs.projection=min(cs.projection,prod_esc(cs.n,v[i]-cs.p1));
  return cs;
}

ContactSide compute_max_projection_contact_side(vector<Point> &v1,vector<Point> &v2)
{
  ContactSide cs=compute_min_projection_contact_side(v1[0],v1[1],v2);
  for (int i=1;i<int(v1.size());i++) {
    int nexti=(i+1)%int(v1.size());
    cs=max(cs,compute_min_projection_contact_side(v1[i],v1[nexti],v2));
  }
  return cs;
}

void compute_contacts_convex_convex(Fixture &f1,Fixture &f2,vector<Point> vp2,ContactsGraph &contacts_graph,
				    ContactSide &cs)
{
  for (int i=0;i<int(vp2.size());i++) {
    Point p2=vp2[i];
    if (prod_esc(cs.n,p2-cs.p1)<error) {
      Contact con;
      con.n=cs.n;
      con.b1=f1.b;
      con.b2=f2.b;
      con.projection=prod_esc(cs.n,p2-cs.p1);
      con.res=min(f1.res,f2.res);
      con.f=min(f1.f,f2.f);
      Point projection=p2+prod_esc(cs.n,cs.p1-p2)*cs.n;
      double pv=prod_vec(cs.n,projection-cs.p1);
      if (pv<-error)
	con.p=0.5*(p2+cs.p1-projection+cs.p1);
      else if (pv>prod_vec(cs.n,cs.p2-cs.p1)+error)
	con.p=0.5*(p2+cs.p2-projection+cs.p2);
      else
	con.p=0.5*(p2+projection);
      contacts_graph.insert(con);
    }
  }
}

void compute_contacts_convex_convex(Fixture &f1,Fixture &f2,ContactsGraph &contacts_graph)
{
  vector<Point> vp1=get_absolute_points(f1);
  vector<Point> vp2=get_absolute_points(f2);
  ContactSide cs1=compute_max_projection_contact_side(vp1,vp2);
  ContactSide cs2=compute_max_projection_contact_side(vp2,vp1);
  if (cs1<cs2) {
    if (cs2.projection>error) return;
    compute_contacts_convex_convex(f2,f1,vp1,contacts_graph,cs2);
  } else {
    if (cs1.projection>error) return;
    compute_contacts_convex_convex(f1,f2,vp2,contacts_graph,cs1);
  }
}

void compute_contacts_circle_circle(Fixture &f1,Fixture &f2,ContactsGraph &contacts_graph)
{
  Point c1=get_absolute_point(f1);
  Point c2=get_absolute_point(f2);
  Contact con;
  con.projection=abs(c2-c1)-(f1.r+f2.r);
  if (con.projection>error) return;
  if (abs(c2-c1)<error) con.n=Point(1,0);
  else con.n=unitary(c2-c1);
  Point p1=c1+con.n*f1.r;
  Point p2=c2-con.n*f2.r;
  con.p=0.5*(p1+p2);
  con.b1=f1.b;
  con.b2=f2.b;
  con.res=min(f1.res,f2.res);
  con.f=min(f1.f,f2.f);
  contacts_graph.insert(con);
}

struct ContactPoint {
  Point p;
  Point n;
};

// pprev,p,pnext are consecutive points of a convex.
// The returned contact point is centered at p.
// The normal points from p to c if the angle pprev,p,pnext contains c.
// Otherwise, the normal points from c to p.
ContactPoint compute_contact_point(Point c,Point pprev,Point p,Point pnext)
{
  ContactPoint cp;
  cp.p=p;
  if (abs(c-p)<error) cp.n=unitary(unitary(pprev-p)+unitary(pnext-p));
  else if (prod_vec(pnext-p,c-p)>0 and prod_vec(c-p,pprev-p)>0) cp.n=unitary(c-p);
  else cp.n=unitary(p-c);
  return cp;
}

// Returns the closest contact point to c among cp1 and cp2.
ContactPoint compute_contact_point(Point c,ContactPoint cp1,ContactPoint cp2)
{
  if (abs(c-cp1.p)<abs(c-cp2.p)) return cp1;
  return cp2;
}

// p0,p1,p2,p3 are consecutive points of a convex (perhaps p0==p3).
// If the closest point to c from the segment (p1,p2) either p1 or p2,
// then this function returns the closest contact point to c among the
// results of the calls compute_contact_point(c,p0,p1,p2)
// and compute_contact_point(p1,p2,p3).
// Otherwise, the closest p to c from the segment (p1,p2) is the
// center of the returned contact point, and the normal points
// to inside the convex.
ContactPoint compute_contact_point(Point c,Point p0,Point p1,Point p2,Point p3)
{
  Point dir=unitary(p2-p1);
  //cout<<"caso ";print(p1);print(p2);print(dir);cout<<endl;
  if (sign(prod_esc(dir,p1-c))==sign(prod_esc(dir,p2-c)))
    return compute_contact_point(c,
				 compute_contact_point(c,p0,p1,p2),
				 compute_contact_point(c,p1,p2,p3));
  //cout<<"supera"<<endl;
  ContactPoint cp;
  cp.n=dir*Point(0,1);
  cp.p=c+prod_esc(cp.n,p1-c)*cp.n;
  return cp;
}

// Computes the closest contact point to c among the points of the
// convex vp.
ContactPoint compute_contact_point(Point c,vector<Point> vp)
{
  //cout<<"compute ";print(c);cout<<" ";print(vp);cout<<endl;
  ContactPoint cp=compute_contact_point(c,vp[0],vp[1],vp[2]);
  for (int i=0;i<int(vp.size());i++) {
    int i0=i;
    int i1=(i+1)%int(vp.size());
    int i2=(i+2)%int(vp.size());
    int i3=(i+3)%int(vp.size());
    cp=compute_contact_point(c,cp,compute_contact_point(c,vp[i0],vp[i1],vp[i2],vp[i3]));
  }
  return cp;
}

void compute_contacts_circle_convex(Fixture &f1,Fixture &f2,ContactsGraph &contacts_graph)
{
  //cout<<"circle convex"<<endl;
  Point c1=get_absolute_point(f1);
  ContactPoint cp=compute_contact_point(c1,get_absolute_points(f2));
  //cout<<"contact point: ";print(cp.p);print(cp.n);cout<<endl;
  Contact con;
  Point perimeter=c1+cp.n*f1.r;
  con.projection=prod_esc(cp.n,cp.p-perimeter);
  //exit(0);
  if (con.projection>error) return;
  con.p=0.5*(cp.p+perimeter);
  con.n=cp.n;
  con.b1=f1.b;
  con.b2=f2.b;
  con.res=min(f1.res,f2.res);
  con.f=min(f1.f,f2.f);
  contacts_graph.insert(con);
  //exit(0);
}

void compute_contacts(Fixture &f1,Fixture &f2,ContactsGraph &contacts_graph)
{
  if (f1.kind==CIRCLE and f2.kind==CIRCLE)
    compute_contacts_circle_circle(f1,f2,contacts_graph);
  else if (f1.kind==CIRCLE and f2.kind==CONVEX)
    compute_contacts_circle_convex(f1,f2,contacts_graph);
  else if (f1.kind==CONVEX and f2.kind==CIRCLE)
    compute_contacts_circle_convex(f2,f1,contacts_graph);
  else
    compute_contacts_convex_convex(f1,f2,contacts_graph);
}

void compute_contacts(Body &b1,Body &b2,ContactsGraph &contacts_graph)
{
  for (int i1=0;i1<int(b1.vf.size());i1++)
    for (int i2=0;i2<int(b2.vf.size());i2++)
      compute_contacts(b1.vf[i1],b2.vf[i2],contacts_graph);
}

// We have a global unique aabb_manager to be reused again and again,
// so that we avoid the use of dynamic memory, and having to
// re-declare such a huge data structure.
AABBManager aabb_manager;


void compute_contacts(vector<Body> &vb,ContactsGraph &contacts_graph)
{
  /*
  for (int i1=0;i1<int(vb.size());i1++)
    for (int i2=i1+1;i2<int(vb.size());i2++)
      if (not (vb[i1].kind==STATIC and vb[i2].kind==STATIC))
	compute_contacts(vb[i1],vb[i2],contacts_graph);
  */
  aabb_manager.reset();
  for (int i=0;i<int(vb.size());i++) {
    vector<Fixture> &vf=vb[i].vf;
    for (int j=0;j<int(vf.size());j++)
      aabb_manager.insert(vf[j]);
  }
  aabb_manager.solve();
  for (int i=0;i<aabb_manager.numsol;i++)
    compute_contacts(*aabb_manager.sol[i].first,*aabb_manager.sol[i].second,contacts_graph);

}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Global movement of the world

// There is just one global variable contacts_graph, to be used by all worlds.
// This way, everything is static.
ContactsGraph contacts_graph;

void move_bodies(vector<Body> &vb,double delta)
{
  for (int i=0;i<int(vb.size());i++) {
    Body &b=vb[i];
    if (b.kind==STATIC) {
      b.v=Point(0,0);
      b.w=0;
      continue;
    }
    b.c+=delta*b.v;
    b.rot+=delta*b.w;
  }
  contacts_graph.reset();
  compute_contacts(vb,contacts_graph);
  contacts_graph.solve();
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Drawing

sf::Font font;

void charge_font()
{
  if (!font.loadFromFile("font.otf")) {
    cout<<"The font could not be charged"<<endl;
    exit(0);
  }
}

void draw_text(sf::RenderWindow &window,int x,int y,string s,sf::Color color)
{
  sf::Text text;
  text.setString(s);
  text.setFont(font);
  text.setColor(color);
  text.setOrigin(sf::Vector2f(0,text.getLocalBounds().height/2.0));
  text.setScale(sf::Vector2f(0.5,0.5));
  //text.setScale(sf::Vector2f(float(ladoboton)/text.getLocalBounds().height,float(ladoboton)/text.getLocalBounds().height));
  text.setPosition(sf::Vector2f(x,y));
  window.draw(text);
}

void draw_text(sf::RenderWindow &window,int x,int y,string s)
{
  draw_text(window,x,y,s,sf::Color::White);
}

void draw_circle(sf::RenderWindow &window,Point p,float r,sf::Color color,bool selected)
{
  sf::CircleShape circle;
  circle.setRadius(r);
  circle.setFillColor(color);
  circle.setOrigin(r,r);
  circle.setPosition(p.x,p.y);
  if (selected) {
    circle.setOutlineThickness(1);
    circle.setOutlineColor(sf::Color::Red);
  }
  window.draw(circle);
}

void draw_polygon(sf::RenderWindow &window,vector<Point> vp,sf::Color color,bool selected)
{
  sf::ConvexShape polygon;
  polygon.setPointCount(int(vp.size()));
  for (int i=0;i<int(vp.size());i++)
    polygon.setPoint(i,sf::Vector2f(vp[i].x,vp[i].y));
  polygon.setFillColor(color);
  if (selected) {
    polygon.setOutlineThickness(1);
    polygon.setOutlineColor(sf::Color::Red);
  }
  window.draw(polygon);
}

int visible=1;

void draw_body(sf::RenderWindow &window,Body &b,bool selected)
{
  if (visible) {
    for (int i=0;i<int(b.vf.size());i++) {
      Fixture &f=b.vf[i];
      sf::Color color=f.owncolor?f.color:b.color;
      if (f.kind==CIRCLE) draw_circle(window,get_absolute_point(f),f.r,color,selected);
      else draw_polygon(window,get_absolute_points(f),color,selected);
    }
  }
  draw_circle(window,b.c,1,sf::Color::Red,false);
}

void draw_world(sf::RenderWindow &window,vector<Body> &vb,int ibkeys)
{
  window.clear(sf::Color::Black);
  draw_text(window,10,20,"DIRECTION: UP,DOWN,RIGHT,LEFT");
  draw_text(window,10,50,"MODE VEL/ACC: F1");
  draw_text(window,10,80,"BODY SELECT: F2");
  draw_text(window,10,110,"EXIT: ESC");
  for (int i=0;i<int(vb.size());i++)
    draw_body(window,vb[i],ibkeys==i);
  window.display();
} 


//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// run world

const int SCRWIDTH  = 600;
const int SCRHEIGHT = 600;
const double VELOCITY=40;
const double ACCELERATION=120;

void read_keys(int mode,Point &a,Point &v,sf::Keyboard::Key up,sf::Keyboard::Key down,sf::Keyboard::Key right,sf::Keyboard::Key left)
{
  if (mode==0) {
    v=Point(0,0);
    if (sf::Keyboard::isKeyPressed(up))
      v+=Point(0,-VELOCITY);
    if (sf::Keyboard::isKeyPressed(down))
      v+=Point(0,VELOCITY);
    if (sf::Keyboard::isKeyPressed(right))
      v+=Point(VELOCITY,0);
    if (sf::Keyboard::isKeyPressed(left))
      v+=Point(-VELOCITY,0);
  } else {
    if (sf::Keyboard::isKeyPressed(up))
      a+=Point(0,-ACCELERATION);
    if (sf::Keyboard::isKeyPressed(down))
      a+=Point(0,ACCELERATION);
    if (sf::Keyboard::isKeyPressed(right))
      a+=Point(ACCELERATION,0);
    if (sf::Keyboard::isKeyPressed(left))
      a+=Point(-ACCELERATION,0);
  }
}

void run(sf::RenderWindow &window,World world)
{
  precompute_world_values(world);
  vector<Body> &vb=world.vb;
  sf::Clock clock;
  int ibkeys=0;
  int mode=1;
  for (;;) {
    sf::Event event;
    while (window.pollEvent(event)) {
      switch (event.type) {
      case sf::Event::Closed:
	window.close();
	exit(0);
	break;
      case sf::Event::KeyPressed:
	if (event.key.code == sf::Keyboard::Escape) {
	  //window.close();
	  return;
	} else if (event.key.code == sf::Keyboard::F1) {
	  mode=(mode+1)%2;
	} else if (event.key.code == sf::Keyboard::F2) {
	  ibkeys=(ibkeys+1)%int(vb.size());
	  //} else if (event.key.code == sf::Keyboard::F3) {
	  //visible=(visible+1)%2;
	}
      case sf::Event::MouseButtonPressed:
      default:
	break;
      }
    }
    double delta=clock.restart().asSeconds();
    Point v(0,0);
    Point a(0,0);
    read_keys(mode,a,v,sf::Keyboard::Up,sf::Keyboard::Down,sf::Keyboard::Right,sf::Keyboard::Left);
    if (mode==0) vb[ibkeys].v=v;
    else vb[ibkeys].v+=delta*a;
    move_bodies(vb,delta);
    draw_world(window,vb,ibkeys);
  }
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Parsing of an input file with a world description

void print(Fixture f)
{
  string desp="      ";
  cout<<desp<<"FIXTURE"<<endl;
  desp+="  ";
  if (f.kind==CIRCLE) {
    cout<<desp<<"kind: CIRCLE"<<endl;
    cout<<desp<<"r: "<<f.r<<endl;
    cout<<desp<<"p: ";print(f.p);cout<<endl;
  } else {
    cout<<desp<<"kind: CONVEX"<<endl;
    cout<<desp<<"vp: ";
    for (int i=0;i<int(f.vp.size());i++)
      print(f.vp[i]);
    cout<<endl;
  }
  cout<<desp<<"d: "<<f.d<<endl;
  cout<<desp<<"f: "<<f.f<<endl;
  cout<<desp<<"res: "<<f.res<<endl;
  cout<<desp<<"owncolor: "<<f.owncolor<<endl;
}

void print(Body b)
{
  string desp="  ";
  cout<<desp<<"BODY"<<endl;
  desp+="  ";
  cout<<desp<<"v: ";print(b.v);cout<<endl;
  cout<<desp<<"w: "<<b.w<<endl;
  for (int i=0;i<int(b.vf.size());i++)
    print(b.vf[i]);
}

void print(World world)
{
  cout<<"WORLD"<<endl;
  cout<<"Description: "<<world.description<<endl;
  for (int i=0;i<int(world.vb.size());i++)
    print(world.vb[i]);
}

struct Token {
  string kind,text;
  double d;
  int line,column;
  Token(){}
  Token(double d,int line,int column):
    d(d),line(line),column(column) {kind="double";}
  Token(string kind,int line,int column):
    kind(kind),line(line),column(column) {d=0;}
  Token(string kind,string text,int line,int column):
    kind(kind),text(text),line(line),column(column) {d=0;}
};

set<string> keywords;
char arraykeywords[][80]={
  "description","static","v","w","vf",
  "r","p","vp","d","f","res","color",
  "Red","Blue","White","Green","Yellow",
  "{","}","[","]","(",")","//",":","\"",",",""};

void init_keywords()
{
  keywords=set<string> ();
  for (int i=0;string(arraykeywords[i])!="";i++)
    keywords.insert(arraykeywords[i]);
}

string read_until_end_of_line(string &s,int &is)
{
  string r;
  while (is<int(s.size()) and s[is]!='\n')
    r+=string(1,s[is++]);
  return r;
}

void read_double(string &s,int &is,int &isiniline,int &line,vector<Token> &vt)
{
  int nextis=is;
  int posdot=-1;
  while (nextis<int(s.size()) and ((s[nextis]>='0' and s[nextis]<='9') or
				   (s[nextis]=='-' and nextis==is) or
				   (posdot==-1 and s[nextis]=='.'))) {
    if (s[nextis]=='.') posdot=nextis;
    nextis++;
  }
  string text=s.substr(is,nextis-is);
  if (text[0]=='-' and (int(text.size())==1 or posdot==1))
    die("Parsing error line "+my_itos(line)+" column "+my_itos(nextis-isiniline+1)+
	": wrong double.");
  vt.push_back(Token(stodouble(text),line,is-isiniline+1));
  is=nextis;
}

void read_token(string &s,int &is,int &isiniline,int &line,vector<Token> &vt)
{
  if (s[is]=='\n') {
    is++;
    isiniline=is;
    line++;
  } else if (s[is]=='-' or (s[is]>='0' and s[is]<='9')) {
    read_double(s,is,isiniline,line,vt);
  } else {
    // Read from big to small string in order to avoid that a prefix of a possible
    // read keyword makes this keyword not considered.
    for (set<string>::reverse_iterator it=keywords.rbegin();it!=keywords.rend();it++) {
      string c=*it;
      if (int(s.size())-is>=int(c.size()) and s.substr(is,int(c.size()))==c) {
	if (c=="//") {
	  read_until_end_of_line(s,is);
	  if (is<int(s.size())) is++;
	  isiniline=is;
	  line++;
	  return;
	} else if (c=="\"") {
	  int isprev=is;
	  for (is++;is<int(s.size()) and s[is]!='"';is++)
	    if (s[is]=='\n')
	      die("Error line "+my_itos(line)+" column "+
		    my_itos(isprev-isiniline+1)+": unfinished string in the same line.");
	  if (is==int(s.size()))
	    die("Error line "+my_itos(line)+" column "+
		my_itos(isprev-isiniline+1)+": unfinished string in the same line.");
	  vt.push_back(Token(c,s.substr(isprev+1,is-isprev-1),line,isprev-isiniline+1));
	  is++;
	  return;
	}
	vt.push_back(Token(c,line,is-isiniline+1));
	is+=int(c.size());
	return;
      }
    }
    string pos=my_itos(is-isiniline+1);
    string err=read_until_end_of_line(s,is);
    die("Error line "+my_itos(line)+" column "+pos+
	": no correspondence is found for \""+err+"\".");
  }
}

void jump_white_spaces(string &s,int &is)
{
  while (is<int(s.size()) and (s[is]==' ' or s[is]=='\t')) is++;
}

void read_tokens(string &s,vector<Token> &vt)
{
  int is=0;
  int line=1;
  int isiniline=0;
  jump_white_spaces(s,is);
  while (is<int(s.size())) {
    read_token(s,is,isiniline,line,vt);
    jump_white_spaces(s,is);
  }
}

vector<Token> read_tokens(string s)
{
  init_keywords();
  vector<Token> vt;
  read_tokens(s,vt);
  return vt;
}


void check_kind(vector<Token> &vt,int &ivt,string t)
{
  if (ivt==int(vt.size()))
    die("Error: the end of the program was found while '"+t+"' was expected.");
  if (vt[ivt].kind!=t)
    die("Error line "+my_itos(vt[ivt].line)+" column "+my_itos(vt[ivt].column)+
	": we expected to see '"+t+"', but we found '"+vt[ivt].kind+"'.");
}

void jump_kind(vector<Token> &vt,int &ivt,string t)
{
  check_kind(vt,ivt,t);
  ivt++;
}

double parsing_double(vector<Token> &vt,int &ivt)
{
  check_kind(vt,ivt,"double");
  return vt[ivt++].d;
}

Point parsing_point(vector<Token> &vt,int &ivt)
{
  jump_kind(vt,ivt,"(");
  double x=parsing_double(vt,ivt);
  jump_kind(vt,ivt,",");
  double y=parsing_double(vt,ivt);
  jump_kind(vt,ivt,")");
  return Point(x,y);
}

void die_unexpected(vector<Token> &vt,int &ivt)
{
  if (ivt>=int(vt.size()))
    die("Error: The end of the input was reached unexpectedly");
  die("Error line "+my_itos(vt[ivt].line)+" column "+my_itos(vt[ivt].column)+": '"+vt[ivt].kind+
      "' was not expected.");
}

sf::Color parsing_color(vector<Token> &vt,int &ivt)
{
  if (ivt>=int(vt.size())) die_unexpected(vt,ivt);
  else if (vt[ivt].kind=="Red") {ivt++;return sf::Color::Red;}
  else if (vt[ivt].kind=="Green") {ivt++;return sf::Color::Green;}
  else if (vt[ivt].kind=="Blue") {ivt++;return sf::Color::Blue;}
  else if (vt[ivt].kind=="Yellow") {ivt++;return sf::Color::Yellow;}
  else if (vt[ivt].kind=="White") {ivt++;return sf::Color::White;}
  else die_unexpected(vt,ivt);
  return sf::Color::Black;
}

/*
  Fixture(double r,Point p,double d,double f,double res,sf::Color color):
  Fixture(vector<Point> vpin,double d,double f,double res,sf::Color color):d(d),f(f),res(res),colo
  Body(Point v,double w,sf::Color color):v(v),w(w),color(color) {}
*/

Fixture parsing_fixture(vector<Token> &vt,int &ivt)
{
  Fixture f;
  jump_kind(vt,ivt,"{");
  while (ivt<int(vt.size()) and vt[ivt].kind!="}") {
    if (vt[ivt].kind=="r") {
      f.kind=CIRCLE;
      ivt++;
      jump_kind(vt,ivt,":");
      f.r=parsing_double(vt,ivt);
    } else if (vt[ivt].kind=="p") {
      f.kind=CIRCLE;
      ivt++;
      jump_kind(vt,ivt,":");
      f.p=parsing_point(vt,ivt);
    } else if (vt[ivt].kind=="d") {
      ivt++;
      jump_kind(vt,ivt,":");
      f.d=parsing_double(vt,ivt);
    } else if (vt[ivt].kind=="f") {
      ivt++;
      jump_kind(vt,ivt,":");
      f.f=parsing_double(vt,ivt);
    } else if (vt[ivt].kind=="res") {
      ivt++;
      jump_kind(vt,ivt,":");
      f.res=parsing_double(vt,ivt);
    } else if (vt[ivt].kind=="color") {
      ivt++;
      jump_kind(vt,ivt,":");
      f.owncolor=true;
      f.color=parsing_color(vt,ivt);
    } else if (vt[ivt].kind=="vp") {
      f.kind=CONVEX;
      ivt++;
      jump_kind(vt,ivt,":");
      jump_kind(vt,ivt,"[");
      while (ivt<int(vt.size()) and vt[ivt].kind!="]")
	f.vp.push_back(parsing_point(vt,ivt));
      jump_kind(vt,ivt,"]");
    } else die_unexpected(vt,ivt);
  }
  jump_kind(vt,ivt,"}");
  return f;
}

Body parsing_body(vector<Token> &vt,int &ivt)
{
  Body b;
  jump_kind(vt,ivt,"{");
  while (ivt<int(vt.size()) and vt[ivt].kind!="}") {
    if (vt[ivt].kind=="static") {
      ivt++;
      b.kind=STATIC;
    } else if (vt[ivt].kind=="v") {
      ivt++;
      jump_kind(vt,ivt,":");
      b.v=parsing_point(vt,ivt);
    } else if (vt[ivt].kind=="w") {
      ivt++;
      jump_kind(vt,ivt,":");
      b.w=parsing_double(vt,ivt);
    } else if (vt[ivt].kind=="vf") {
      ivt++;
      jump_kind(vt,ivt,":");
      jump_kind(vt,ivt,"[");
      while (ivt<int(vt.size()) and vt[ivt].kind!="]")
	b.vf.push_back(parsing_fixture(vt,ivt));
      jump_kind(vt,ivt,"]");
    } else if (vt[ivt].kind=="color") {
      ivt++;
      jump_kind(vt,ivt,":");
      b.color=parsing_color(vt,ivt);
    } else die_unexpected(vt,ivt);
  }
  jump_kind(vt,ivt,"}");
  return b;
}

World parsing_world(vector<Token> vt)
{
  int ivt=0;
  World world;
  while (ivt<int(vt.size())) {
    if (vt[ivt].kind=="description") {
      jump_kind(vt,ivt,"description");
      jump_kind(vt,ivt,":");
      check_kind(vt,ivt,"\"");
      world.description=vt[ivt].text;
      ivt++;
    } else world.vb.push_back(parsing_body(vt,ivt));
  }
  if (int(world.vb.size())==0)
    die("Error: the world must have at least one body");
  return world;
}

World read_world(string filename)
{
  cout<<"Parsing world file \""<<filename<<"\""<<endl;
  return parsing_world(read_tokens(read_file(filename)));
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// main

vector<World> read_world_files()
{
  istringstream mycin(read_file("worldfiles"));
  string filename;
  vector<World> vw;
  while (mycin>>filename)
    vw.push_back(read_world(filename));
  return vw;
}

int main()
{
  vector<World> vw=read_world_files();
  sf::RenderWindow window;
  window.create(sf::VideoMode(SCRWIDTH,SCRHEIGHT),"Inertial momentum");
  charge_font();
  int selection=0;
  for (;;) {
    sf::Event event;
    while (window.pollEvent(event)) {
      switch (event.type) {
      case sf::Event::Closed:
	window.close();
	exit(0);
	break;
      case sf::Event::KeyPressed:
	if (event.key.code == sf::Keyboard::Escape) {
	  window.close();
	  exit(0);
	} else if (event.key.code == sf::Keyboard::Return) {
	  run(window,vw[selection]);
	} else if (event.key.code == sf::Keyboard::Up) {
	  selection=(selection-1+int(vw.size()))%(int(vw.size()));
	} else if (event.key.code == sf::Keyboard::Down) {
	  selection=(selection+1)%(int(vw.size()));
	}
	break;
      case sf::Event::MouseButtonPressed:
      default:
	break;
      }
    }
    window.clear(sf::Color::Black);
    draw_text(window,50,100,"Selection keys: UP,DOWN,ENTER,ESC");
    for (int i=0;i<int(vw.size());i++)
      draw_text(window,50,150+30*i,vw[i].description,selection==i?(sf::Color::Red):(sf::Color::White));
    window.display();
  }
}
