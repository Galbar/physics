#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/Graphics/Shape.hpp>
#include <SFML/Graphics/RectangleShape.hpp>

#include <iostream>
#include <complex>
#include <cmath>
#include <fstream>
#include <cstdlib>
#include <queue>
#include <sstream>
#include <algorithm>

//#include "Box2D/Box2D.h"


using namespace std;

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Basic functions

double sq(double x)
{
  return x*x;
}

double error=1e-5;

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Definition of points

typedef complex<double> point;

double prod_esc(point p1,point p2)
{
  return real(conj(p1)*p2);
}

double prod_vec(point p1,point p2)
{
  return imag(conj(p1)*p2);
}

point unitary(point p)
{
  return (1.0/abs(p))*p;
}

double convex_oriented_area(vector<point> vp)
{
  double a=0;
  for (int i=1;i<int(vp.size())-1;i++)
    a+=prod_vec(vp[i]-vp[0],vp[i+1]-vp[0])/2.0;
  return a;
}

double convex_area(vector<point> vp)
{
  return abs(convex_oriented_area(vp));
}

point triangle_center(point p1,point p2,point p3)
{
  return 1/3.0*(p1+p2+p3);
}

double triangle_area(point p1,point p2,point p3)
{
  return abs(prod_vec(p2-p1,p3-p1)/2.0);
}

// Computes the inertial momentum of a triangle with respect
// to a position c, with the incorrect assumption that
// all its mass was concentrated on its center of masses,
// although it is uniformly distributed with density d,
// in order to make just an approximation.
double basic_triangle_inertia(point p1,point p2,point p3,double d,point c)
{
  return norm(triangle_center(p1,p2,p3)-c)*d*triangle_area(p1,p2,p3);
}

// Approximate computation of inertial momentum of
// a triangle with density d, and with respect to a position c,
// based on approximating integration. Basically, it divides
// the triangle in small triangles for which the
// previous basic_triangle_inertia function is computed.
double triangle_inertia(point p1,point p2,point p3,double d,point c)
{
  double I=0;
  for (int i=0;i<10;i++) {
    double x=i/10.0;
    double nextx=(i+1)/10.0;
    point pa=(1.0-x)*p1+x*p2;
    point pb=(1.0-nextx)*p1+nextx*p2;
    for (int j=0;j<10;j++) {
      double y=j/10.0;
      double nexty=(j+1)/10.0;
      point pc=pa*(1.0-y)+y*p3;
      point pd=pb*(1.0-y)+y*p3;
      point pe=pa*(1.0-nexty)+nexty*p3;
      point pf=pb*(1.0-nexty)+nexty*p3;
      I+=basic_triangle_inertia(pc,pd,pe,d,c)+basic_triangle_inertia(pd,pf,pe,d,c);
    }
  }
  return I;
}


//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Definition and initialization of Bodies.

// Each fixture is a convex polygon.
struct Fixture {
  vector<point> vp; // positions
  double d; // density
  double f; // friction
  double res; // restitution
  sf::Color color; // surrounding color
  Fixture() {}
  // vp must represent a convex polygon as a list of clock-wise or counter-clock-wise points.
  Fixture(vector<point> vpin,double din,double fin,double resin,sf::Color colorin) {
    vp=vpin;d=din;f=fin;res=resin;color=colorin;
    if (convex_oriented_area(vp)<0)
      reverse(vp.begin(),vp.end());
  }
};

struct Body {
  point c; // mass center
  double rot; // rotation w.r.t. center
  point v; // linear velocity
  double w; // angular velocity
  double I; // inertial momentum
  double m; // mass
  vector<Fixture> vf;
  sf::Color color; // Interior color of each fixture.
  Body() {}
  Body(point v,double w,sf::Color color):v(v),w(w),color(color) {}
};

point get_point(Body &b,point p)
{
  return b.c+polar(1.0,b.rot)*p;
}

double compute_mass(Fixture &f)
{
  return f.d*convex_area(f.vp);
}

void compute_mass(Body &b)
{
  b.m=0;
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++)
    b.m+=compute_mass(vf[i]);
}

point compute_mass_sum_vector(Fixture &f)
{
  vector<point> &vp=f.vp;
  point c(0,0);
  for (int i=1;i<int(vp.size())-1;i++)
    c+=f.d*triangle_area(vp[0],vp[i],vp[i+1])*triangle_center(vp[0],vp[i],vp[i+1]);
  //c/=compute_mass(f);
  return c;
}

void compute_mass_center(Body &b)
{  
  b.c=point(0,0);
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++)
    b.c+=compute_mass_sum_vector(vf[i]);
  b.c=(1.0/b.m)*b.c;
}

// Approximate computation of inertial momentum of
// a Fixture with respect to a position c.
double compute_inertia(Fixture f,point c)
{
  double I=0;
  vector<point> &vp=f.vp;
  for (int i=1;i<int(vp.size())-1;i++)
    I+=triangle_inertia(vp[0],vp[i],vp[i+1],f.d,c);
  return I;
}

// Approximate computation of inertial momentum of a Body
// with respect to its mass center.
void compute_inertia(Body &b)
{
  b.I=0;
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++)
    b.I+=compute_inertia(vf[i],b.c);
}

void make_positions_relative_to_mass_center(Body &b)
{
  vector<Fixture> &vf=b.vf;
  for (int i=0;i<int(vf.size());i++) {
    vector<point> &vp=vf[i].vp;
    for (int j=0;j<int(vp.size());j++)
      vp[j]-=b.c;
  }
}

// This function assumes that the Fixtures of b have the positions
// initialized as absolute coordinates, and all the rest of atributes initialized as well.
// The function computes the total mass, mass center, inertial momentum
// of the body, and make the positions of the fixtures relative to
// the mass center. It initializes the rotation to 0, and assumes
// that the linear and angular velocities are already initialized,
void precompute_body_values(Body &b)
{
  compute_mass(b);
  compute_mass_center(b);
  compute_inertia(b);
  make_positions_relative_to_mass_center(b);
  b.rot=0;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Detection of collisions

struct CollisionSide {
  point p1,p2;
  point n;
  double projection; // Negated of penetration
};

bool operator<(CollisionSide cs1,CollisionSide cs2)
{
  return cs1.projection<cs2.projection;
}

void print(point p)
{
  cout<<"("<<real(p)<<","<<imag(p)<<")"<<endl;
}

void print(vector<point> v)
{
  for (int i=0;i<int(v.size());i++)
    cout<<"("<<real(v[i])<<","<<imag(v[i])<<")";
  cout<<endl;
}

CollisionSide compute_min_projection_collision_side(point p1,point p2,vector<point> &v)
{
  CollisionSide cs;
  cs.p1=p1;
  cs.p2=p2;
  cs.n=unitary((p2-p1)*point(0,-1));
  cs.projection=prod_esc(cs.n,v[0]-cs.p1);
  for (int i=1;i<int(v.size());i++)
    cs.projection=min(cs.projection,prod_esc(cs.n,v[i]-cs.p1));
  return cs;
}

CollisionSide compute_max_projection_collision_side(vector<point> &v1,vector<point> &v2)
{
  CollisionSide cs=compute_min_projection_collision_side(v1[0],v1[1],v2);
  for (int i=1;i<int(v1.size());i++) {
    int nexti=(i+1)%int(v1.size());
    cs=max(cs,compute_min_projection_collision_side(v1[i],v1[nexti],v2));
  }
  return cs;
}

struct Collision {
  point p;
  point n; // normal outgoing from b1
  Body *b1;
  Body *b2;
  double projection; // negation of penetration.
  double res; // restitution
  double f; // friction
};

bool operator<(Collision c1,Collision c2)
{
  return c1.projection<c2.projection;
}

void compute_collisions(Body &b1,int i1,Body &b2,int i2,vector<point> vp2,
			vector<Collision> &vc,CollisionSide &cs)
{
  Fixture &f1=b1.vf[i1];
  Fixture &f2=b2.vf[i2];
  for (int i=0;i<int(vp2.size());i++) {
    point p2=vp2[i];
    if (prod_esc(cs.n,p2-cs.p1)<error) {
      Collision c;
      c.n=cs.n;
      c.b1=&b1;
      c.b2=&b2;
      c.projection=prod_esc(cs.n,p2-cs.p1);
      c.res=min(f1.res,f2.res);
      c.f=min(f1.f,f2.f);
      point projection=p2+prod_esc(cs.n,cs.p1-p2)*cs.n;
      double pv=prod_vec(cs.n,projection-cs.p1);
      if (pv<-error)
	c.p=0.5*(p2+cs.p1-projection+cs.p1);
      else if (pv>prod_vec(cs.n,cs.p2-cs.p1)+error)
	c.p=0.5*(p2+cs.p2-projection+cs.p2);
      else
	c.p=0.5*(p2+projection);
      vc.push_back(c);
    }
  }
}

vector<point> get_absolute_points(Body &b,Fixture &f)
{
  vector<point> vp;
  for (int j=0;j<int(f.vp.size());j++)
    vp.push_back(get_point(b,f.vp[j]));
  return vp;
}

void compute_collisions(Body &b1,int i1,Body &b2,int i2,
			vector<Collision> &vc)
{
  Fixture &f1=b1.vf[i1];
  vector<point> vp1=get_absolute_points(b1,f1);
  Fixture &f2=b2.vf[i2];
  vector<point> vp2=get_absolute_points(b2,f2);
  CollisionSide cs1=compute_max_projection_collision_side(vp1,vp2);
  CollisionSide cs2=compute_max_projection_collision_side(vp2,vp1);
  if (cs1<cs2) {
    if (cs2.projection>error) return;
    compute_collisions(b2,i2,b1,i1,vp1,vc,cs2);
  } else {
    if (cs1.projection>error) return;
    compute_collisions(b1,i1,b2,i2,vp2,vc,cs1);
  }
}

void compute_collisions(Body &b1,Body &b2,vector<Collision> &vc)
{
  for (int i1=0;i1<int(b1.vf.size());i1++)
    for (int i2=0;i2<int(b2.vf.size());i2++)
      compute_collisions(b1,i1,b2,i2,vc);
}

vector<Collision> compute_collisions(vector<Body> &vb)
{
  vector<Collision> vc;
  for (int i1=0;i1<int(vb.size());i1++)
    for (int i2=i1+1;i2<int(vb.size());i2++)
      compute_collisions(vb[i1],vb[i2],vc);
  return vc;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Resolution of collisions

struct Resolution {
  Body *b;
  point p;
  point impulse;
  Resolution() {}
  Resolution(Body *b,point p,point impulse):b(b),p(p),impulse(impulse) {}
};

void apply_impulse(Body &b,point p,point impulse)
{
  b.v+=(1.0/b.m)*impulse;
  b.w+=(1.0/b.I)*prod_vec(p-b.c,impulse);
}

point get_velocity(Body &b,point p)
{
  return b.v+b.w*(point(0,1)*(p-b.c));
}


/*
struct Collision {
  point p;
  point n; // normal outgoing from b1
  Body *b1;
  Body *b2;
  double res; // restitution
  double f; // friction
};
 */
vector<Resolution> compute_resolution(Collision col)
{
  vector<Resolution> vr;
  point p=col.p;
  point n=col.n;
  Body &b1=*col.b1;
  Body &b2=*col.b2;
  double res=col.res;
  point v1=get_velocity(b1,p);
  point v2=get_velocity(b2,p);
  point v21=v2-v1;
  if (prod_esc(v21,n)>=0) return vr;
  double factor=-(1+res)*prod_esc(v21,n)/
      (1.0/b1.m+1.0/b2.m+sq(prod_vec(p-b1.c,n))/b1.I+sq(prod_vec(p-b2.c,n))/b2.I);
  vr.push_back(Resolution(&b1,p,(-factor)*n));
  vr.push_back(Resolution(&b2,p,factor*n));
  return vr;
}

void resolve_collisions(vector<Collision> vc)
{
  for (int paso=0;paso<20;paso++) {
    bool found=false;
    for (int i=0;i<int(vc.size()) and not found;i++) {
      vector<Resolution> vr=compute_resolution(vc[i]);
      if (int(vr.size())>0) {
	found=true;
	for (int i=0;i<int(vr.size());i++) {
	  Resolution &r=vr[i];
	  apply_impulse(*r.b,r.p,r.impulse);
	}
      }
    }
    if (not found) return;
  }
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Global movement of the world

void move_bodies(vector<Body> &vb,double delta)
{
  for (int i=0;i<int(vb.size());i++) {
    Body &b=vb[i];
    b.c+=delta*b.v;
    b.rot+=delta*b.w;
  }
  resolve_collisions(compute_collisions(vb));
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Drawing

sf::Font font;

void charge_font()
{
  if (!font.loadFromFile("font.otf")) {
    cout<<"The font could not be charged"<<endl;
    exit(0);
  }
}

void draw_text(sf::RenderWindow &window,int x,int y,string s)
{
  sf::Text text;
  text.setString(s);
  text.setFont(font);
  text.setColor(sf::Color::White);
  text.setOrigin(sf::Vector2f(0,text.getLocalBounds().height/2.0));
  text.setScale(sf::Vector2f(0.5,0.5));
  //text.setScale(sf::Vector2f(float(ladoboton)/text.getLocalBounds().height,float(ladoboton)/text.getLocalBounds().height));
  text.setPosition(sf::Vector2f(x,y));
  window.draw(text);
}

void draw_circle(sf::RenderWindow &window,float x,float y,float r,sf::Color color)
{
  sf::CircleShape circle;
  circle.setRadius(r);
  circle.setFillColor(color);
  circle.setOrigin(r,r);
  circle.setPosition(x,y);
  window.draw(circle);
}

void draw_polygon(sf::RenderWindow &window,vector<point> vp,sf::Color color)
{
  sf::ConvexShape polygon;
  polygon.setPointCount(int(vp.size()));
  for (int i=0;i<int(vp.size());i++)
    polygon.setPoint(i,sf::Vector2f(real(vp[i]),imag(vp[i])));
  polygon.setFillColor(color);
  window.draw(polygon);
}

int visible=1;

void draw_body(sf::RenderWindow &window,Body &b)
{
  if (visible)
    for (int i=0;i<int(b.vf.size());i++)
      draw_polygon(window,get_absolute_points(b,b.vf[i]),b.vf[i].color);
  draw_circle(window,real(b.c),imag(b.c),1,sf::Color::Red);
}

void draw_world(sf::RenderWindow &window,vector<Body> &vb)
{
  window.clear(sf::Color::Black);
  draw_text(window,10,10,"DIRECTION: UP,DOWN,RIGHT,LEFT");
  draw_text(window,10,40,"MODE VEL/ACC: F1");
  draw_text(window,10,70,"BODY SELECT: F2");
  draw_text(window,10,100,"EXIT: ESC");  
  for (int i=0;i<int(vb.size());i++)
    draw_body(window,vb[i]);
  window.display();
} 


//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// main

const int SCRWIDTH  = 600;
const int SCRHEIGHT = 600;
const double VELOCITY=40;
const double ACCELERATION=120;

void read_keys(int mode,point &a,point &v,sf::Keyboard::Key up,sf::Keyboard::Key down,sf::Keyboard::Key right,sf::Keyboard::Key left)
{
  if (mode==0) {
    v=point(0,0);
    if (sf::Keyboard::isKeyPressed(up))
      v+=point(0,-VELOCITY);
    if (sf::Keyboard::isKeyPressed(down))
      v+=point(0,VELOCITY);
    if (sf::Keyboard::isKeyPressed(right))
      v+=point(VELOCITY,0);
    if (sf::Keyboard::isKeyPressed(left))
      v+=point(-VELOCITY,0);
  } else {
    if (sf::Keyboard::isKeyPressed(up))
      a+=point(0,-ACCELERATION);
    if (sf::Keyboard::isKeyPressed(down))
      a+=point(0,ACCELERATION);
    if (sf::Keyboard::isKeyPressed(right))
      a+=point(ACCELERATION,0);
    if (sf::Keyboard::isKeyPressed(left))
      a+=point(-ACCELERATION,0);
  }
}

void run(sf::RenderWindow &window,vector<Body> &vb)
{
  for (int i=0;i<int(vb.size());i++)
    precompute_body_values(vb[i]);
  sf::Clock clock;
  int ibkeys=0;
  int mode=1;
  for (;;) {
    sf::Event event;
    while (window.pollEvent(event)) {
      switch (event.type) {
      case sf::Event::Closed:
	window.close();
	exit(0);
	break;
      case sf::Event::KeyPressed:
	if (event.key.code == sf::Keyboard::Escape) {
	  //window.close();
	  return;
	} else if (event.key.code == sf::Keyboard::F1) {
	  mode=(mode+1)%2;
	} else if (event.key.code == sf::Keyboard::F2) {
	  ibkeys=(ibkeys+1)%int(vb.size());
	} else if (event.key.code == sf::Keyboard::F3) {
	  visible=(visible+1)%2;
	}
      case sf::Event::MouseButtonPressed:
      default:
	break;
      }
    }
    double delta=clock.restart().asSeconds();
    point v(0,0);
    point a(0,0);
    read_keys(mode,a,v,sf::Keyboard::Up,sf::Keyboard::Down,sf::Keyboard::Right,sf::Keyboard::Left);
    if (mode==0) vb[ibkeys].v=v;
    else vb[ibkeys].v+=delta*a;
    move_bodies(vb,delta);
    draw_world(window,vb);
  }
}


int body_points[10][10][10][2]=
  {
    {
      {{100,100},{110,90},{110,110},{0,0}},
      {{200,100},{200,110},{210,110},{210,100},{0,0}},
      {{0,0}}
    }
    ,
    {
      {{300,200},{310,210},{320,200},{0,0}},
      {{350,250},{345,255},{345,260},{350,260},{355,255},{355,250},{0,0}},
      {{280,250},{275,255},{280,260},{285,255},{0,0}},
      {{0,0}}
    }
    ,
    {
      {{0,0}}
    }
  };


/*
int body_points[10][10][10][2]=
  {
    {
      {{100,100},{140,70},{140,130},{0,0}},
      {{0,0}}
    }
    ,
    {
      {{300,200},{320,240},{340,200},{0,0}},
      {{0,0}}
    }
    ,
    {
      {{0,0}}
    }
  };
*/

/*
int body_points[10][10][10][2]=
  {
    {
      {{325,186},{304,225},{348,218},{0,0}},
      {{0,0}}
    }
    ,
    {
      {{282,229},{307,185},{331,240},{0,0}},
      {{0,0}}
    }
    ,
    {
      {{0,0}}
    }
  };
*/

//(325.189,186.157)(304.874,225.998)(348.936,218.346)
//(282.819,229.506)(307.263,185.889)(331.536,240.759)

Fixture array2fixture(int fixture_points[10][2],sf::Color color)
{
  vector<point> vp;
  for (int i=0;not (fixture_points[i][0]==0 and fixture_points[i][1]==0);i++)
    vp.push_back(point(double(fixture_points[i][0]),double(fixture_points[i][1])));
  return Fixture(vp,1,1,0.5,color);
}

Body array2body(int body_points[10][10][2],sf::Color color)
{
  Body b(point(0,0),0,color);
  for (int i=0;not (body_points[i][0][0]==0 and body_points[i][0][1]==0);i++)
    b.vf.push_back(array2fixture(body_points[i],color));
  return b;
}

int main()
{
  sf::RenderWindow window;
  window.create(sf::VideoMode(SCRWIDTH,SCRHEIGHT),"Inertial momentum");
  charge_font();
  vector<Body> vb;
  vb.push_back(array2body(body_points[0],sf::Color::White));
  vb[0].vf[0].color=sf::Color::Yellow;
  vb[0].vf[1].color=sf::Color::Green;
  vb.push_back(array2body(body_points[1],sf::Color::Blue));
  /*
  print(vb[0].vf[0].vp);
  print(vb[1].vf[0].vp);
  for (int i=0;i<int(vb.size());i++)
    precompute_body_values(vb[i]);
  print(get_absolute_points(vb[0],vb[0].vf[0]));
  cout<<convex_oriented_area(get_absolute_points(vb[0],vb[0].vf[0]))<<endl;
  print(get_absolute_points(vb[1],vb[1].vf[0]));
  cout<<convex_oriented_area(get_absolute_points(vb[1],vb[1].vf[0]))<<endl;
  compute_collisions(vb);
  */
  
  run(window,vb);
}
